import customtkinter as ctk
import calendar
from datetime import datetime

class Calendar:
    def __init__(self, window):
        self.window = window
        self.window.title("Custom Calendar")
        self.window.geometry("1030x900") #The size of the window
        self.window_bg = "#91BEE3" #The default colours of differnet components of the calendar
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"

        self.current_year = datetime.now().year #datetime.now gives you the current date and time, by adding .year or .month, it specifically takes just the month or year
        self.current_month = datetime.now().month
        self.selected_day = None #This will store the date that is selected

        nav_frame = ctk.CTkFrame(window, fg_color="#13366b", corner_radius=0)
        nav_frame.pack(fill="x")

        self.prev_btn = ctk.CTkButton(nav_frame, text="<", width=40, command=self.prev_month, fg_color=self.button_bg, text_color=self.button_text) #The button to go to the previous month
        self.prev_btn.pack(side="left", padx=10, pady=5)

        self.next_btn = ctk.CTkButton(nav_frame, text=">", width=40, command=self.next_month, fg_color=self.button_bg, text_color=self.button_text) #The button to go to the next month
        self.next_btn.pack(side="right", padx=10, pady=5)

        self.month_label = ctk.CTkLabel(nav_frame, text="", font=("Arial", 20, "bold"), text_color=self.label_text) #Appearance and placement of the month label
        self.month_label.pack(side="top", pady=5)

        self.cal_frame = ctk.CTkFrame(window, fg_color="#91BEE3")
        self.cal_frame.pack(expand=True, fill="both", padx=10, pady=10)

        self.draw_calendar()
        self.window.configure(fg_color=self.window_bg)

    def draw_calendar(self):
        for widget in self.cal_frame.winfo_children():
            widget.destroy()

        self.month_label.configure(text=f"{calendar.month_name[self.current_month]} {self.current_year}") #The label at the top of the calendar

        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] #List to store all the seven days
        
        for c, day in enumerate(days): #This creates the label from monday to sunday
            lbl = ctk.CTkLabel(self.cal_frame, text=day, font=("Arial", 15, "bold"), fg_color="transparent", text_color=self.label_text)
            lbl.grid(row=0, column=c, padx=2, pady=2, sticky="nsew")  

        month_calendar = calendar.Calendar(firstweekday=0).monthdayscalendar(self.current_year, self.current_month) #this calculate which date number refers to which weekday or weekend
        num_rows = len(month_calendar) #This is the amount of rows needed for the calendar 

        for r, week in enumerate(month_calendar, start=1): #enumerate lets you loop through a list and keep track of the index number at the same time
            for c, day in enumerate(week):
                if day == 0:
    
                    filler = ctk.CTkLabel(self.cal_frame, text="", fg_color="transparent")
                    filler.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")
                    continue
                
                cell_btn = ctk.CTkButton(self.cal_frame, text=str(day), font=("Arial", 12, "bold"), anchor="nw", #This is placement and appearance of the numbers on the top right corner of each box
                                         fg_color=self.button_bg, text_color=self.button_text, hover_color="#3a70c1",
                                         command=lambda d=day: self.select_date(d))
                cell_btn.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")  

        for i in range(7): #This helps with resizing all the components to avoid any bad distortion when the window is resized
            self.cal_frame.grid_columnconfigure(i, weight=1)
        for i in range(1, num_rows + 1):
            self.cal_frame.grid_rowconfigure(i, weight=1)

    def select_date(self, day):
        self.selected_day = day
        print(f"Selected date: {self.current_year}-{self.current_month:02d}-{day:02d}")

    def prev_month(self):
        self.current_month -= 1 #This does the calculation for what month and year it is when you press the "<"
        if self.current_month < 1:
            self.current_month = 12
            self.current_year -= 1
        self.draw_calendar()

    def next_month(self): #This does the calculation for what month and year it is when you press the ">"
        self.current_month += 1
        if self.current_month > 12:
            self.current_month = 1
            self.current_year += 1
        self.draw_calendar()

if __name__ == "__main__":
    ctk.set_appearance_mode("system")
    window = ctk.CTk()
    app = Calendar(window)
    window.mainloop()
