import tkinter as tk  # This imports tkinter
from PIL import Image, ImageTk  # This imports PIL so I am able to use images

class Pet:
    def __init__(self, window, default_img_path, interact_img_path):
        self.window = window
        self.load_images(default_img_path, interact_img_path) #This finds the picture from the folder and loads it into the code
        
        self.label = tk.Label(window, image=self.default_img) #This displays the cat1.jpg as default 
        self.label.grid()
        
        self.label.bind("<Button-1>", self.click) #This binds the mouse control to the image which is binded to a function
        self.label.bind("<ButtonRelease-1>", self.release)
    
    def load_images(self, default_img_path, interact_img_path):
        default_img = Image.open(default_img_path) #opens the image
        interact_img = Image.open(interact_img_path)
        default_img = default_img.resize((410, 900))  # reiszing the image
        interact_img = interact_img.resize((410, 900))
        
        self.default_img = ImageTk.PhotoImage(default_img) #This converts the jpg into a format that is compatible with tkinter
        self.interact_img = ImageTk.PhotoImage(interact_img)
    
    def click(self, event):  #Function when image is clicked
        self.label.config(image=self.interact_img)  # Changes to interaction image
    
    def release(self, event):  # Function when mouse is released
        self.label.config(image=self.default_img) #event has to be used here to avoid the code from crashing

class Cat(Pet): #Polymorphism is used here to aboid copying and pasting code
    def __init__(self, window):
        super().__init__(window, "cat_default.png", "cat_interact.png") #Calls Pet's __init__ with the specific images 

class Dog(Pet):
    def __init__(self, window):
        super().__init__(window, "dog_default.png", "dog_interact.png")

class Bunny(Pet):
    def __init__(self, window):
        super().__init__(window, "bunny_default.png", "bunny_interact.png")

class Goldfish(Pet):
    def __init__(self, window):
        super().__init__(window, "goldfish_default.png", "goldfish_interact.png")

class Hamster(Pet):
    def __init__(self, window):
        super().__init__(window, "hamster_default.png", "hamster_interact.png")  


window = tk.Tk() 
window.title("Virtual Pets") 

hamster = Hamster(window)
cat= Cat(window)
dog= Dog(window)
bunny= Bunny(window)
goldfish= Goldfish(window)


window.mainloop() 
