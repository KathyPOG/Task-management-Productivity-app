import tkinter as tk #this imports pythons standard gui library
from PIL import Image, ImageTk #this imports a library which allows me to manipulate image files
import customtkinter as ctk #this imports a more advanced gui library
from tkinter import messagebox, simpledialog, colorchooser #this imports tools that pops up
from datetime import datetime 
import calendar #this imports a module that helps with month/day layout
import random #this imports the ability to generate a random number

class Pet: #This is the parent class that holds all the functions to load the image for the pets, different emote of the pets, etc which will be used for inheritance
    def __init__(self, window, default_img_path, interact_img_path, addtask_img_path, pet_name):
        self.window = window
        self.pet_name = pet_name
        self.default_img_path = default_img_path #The images have been named like this so it can load any images in 
        self.interact_img_path = interact_img_path
        self.addtask_img_path = addtask_img_path
        self.load_images(default_img_path, interact_img_path, addtask_img_path) #This loads the image in so it is compatible with tkinter
        
        self.container = tk.Frame(window, bg="#91BEE3", width=410, height=900) #This chunk of code sets up the containers for the pet in
        self.container.grid(row=0, column=0, padx=(0, 10))
        self.container.grid_propagate(False) #self.container.grid_propagate ensures that the size of the window will not change regardless of how big any content is
        self.container.grid_rowconfigure(0, weight=0) #The 0, 1, 2 is just another way of writing row so 0= row=0 etc
        self.container.grid_rowconfigure(1, weight=1) #weight=1 means that the row will take up any extra space in the container
        self.container.grid_rowconfigure(2, weight=0) #weight=0 means that the row will not change in size at all
        self.container.grid_columnconfigure(0, weight=1)
        
        self.nav_buttons_frame = tk.Frame(self.container, bg="#91BEE3", width=410, height=80) #this creates a frame which is holding the "KANBAN" and "calendar" button
        self.nav_buttons_frame.grid(row=0, column=0, sticky="nsew", pady=(10, 10))
        self.nav_buttons_frame.grid_propagate(False)
        
        self.image_frame = tk.Frame(self.container, bg="#91BEE3", width=410, height=500) #This is the frame that is holding the image of the virtual pet
        self.image_frame.grid(row=1, column=0, sticky="nsew", pady=20)
        self.image_frame.grid_propagate(False) #since the size of the image of the virtual pet is set, i added self.image_frame.grid_propagate(False) to avoid the frame from changing size
        self.image_frame.grid_rowconfigure(0, weight=1)
        self.image_frame.grid_columnconfigure(0, weight=1)
        
        self.label = tk.Label(self.image_frame, image=self.default_img, bg="#91BEE3")
        self.label.grid(row=0, column=0)
        
        self.kanban_btn = None #None is used as a placeholder for the buttons which will be added later
        self.calendar_btn = None
        
        self.label.bind("<Button-1>", self.click) #This binds the trackpad/mouse control to a function 
        self.label.bind("<ButtonRelease-1>", self.release)
    
    def load_images(self, default_img_path, interact_img_path, addtask_img_path):
        default_img = Image.open(default_img_path) #This opens the image
        interact_img = Image.open(interact_img_path)
        addtask_img = Image.open(addtask_img_path)
        
        default_img = default_img.resize((410, 500)) #This resizes the image to 410x500
        interact_img = interact_img.resize((410, 500))
        addtask_img = addtask_img.resize((410, 500))
        
        self.default_img = ImageTk.PhotoImage(default_img) #This converts the PIL image to PhotoImage objects that tkinter can display as a label or a button
        self.interact_img = ImageTk.PhotoImage(interact_img)
        self.addtask_img = ImageTk.PhotoImage(addtask_img)
    
    def click(self, event): #This changes the image of the default image to the interact image when the pet is clicked
        self.label.config(image=self.interact_img)
    
    def release(self, event): #When the image is released, the image will return back to the default image
        self.label.config(image=self.default_img)
    
    def show_addtask_animation(self): #This is the function that changes the default image to the add_task image when a task is added into the KANBAN baord
        self.label.config(image=self.addtask_img) 
        self.window.after(2000, lambda: self.label.config(image=self.default_img)) #2000 is 2000 milliseconds so the add_task image will be displayed for 2 seconds
    
    def show_deletetask_animation(self):  #This is the function that changes the default image to the delete_task image when a task is deleted 
        if random.choice([True, False]): #True and false has been added so there is a 50% chance to either display delete_task1 or delete_task2 
            deletetask_img = Image.open(self.default_img_path.replace("default", "deletetask"))
        else:
            deletetask_img = Image.open(self.default_img_path.replace("default", "deletetask2"))
        
        deletetask_img = deletetask_img.resize((410, 500))
        self.deletetask_img = ImageTk.PhotoImage(deletetask_img)
        
        self.label.config(image=self.deletetask_img)
        self.window.after(2000, lambda: self.label.config(image=self.default_img))
    
    def update_background_color(self, color): #This is the function that changes the default colour of the background colour to the chosen colour
        self.label.configure(bg=color)
        self.container.configure(bg=color)
        self.name_label.configure(bg=color)
        self.nav_buttons_frame.configure(bg=color)
        self.image_frame.configure(bg=color)
        self.window.configure(bg=color)
    
    def update_nav_button_colors(self, button_bg, button_text): #This is the function that changes the default colour of the "KANBAN" and "Calendar" button to the chosen colour
        if self.kanban_btn:
            self.kanban_btn.configure(fg_color=button_bg, text_color=button_text)
        if self.calendar_btn:
            self.calendar_btn.configure(fg_color=button_bg, text_color=button_text)

class Cat(Pet): #All of the child classes inherits from the parent class which is class Pet
    def __init__(self, window, pet_name):
        super().__init__(window, "cat_default.png", "cat_interact.png", "cat_addtask.png", pet_name)

class Dog(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "dog_default.png", "dog_interact.png", "dog_addtask.png", pet_name)

class Bunny(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "bunny_default.png", "bunny_interact.png", "bunny_addtask.png", pet_name)

class Goldfish(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "goldfish_default.png", "goldfish_interact.png", "goldfish_addtask.png", pet_name)

class Hamster(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "hamster_default.png", "hamster_interact.png", "hamster_addtask.png", pet_name)

class Pet_Option: #This is the parent class to load all the images of pet option
    def __init__(self, name):
        self.name = name
    
    def get_normal_image(self):
        return ImageTk.PhotoImage(Image.open(f"{self.name}_nonselect.png").resize((250, 250))) #this open and loads the select and nonselect images
    def get_hover_image(self):
        return ImageTk.PhotoImage(Image.open(f"{self.name}_select.png").resize((250, 250))) #This resizes the image to 250x250

    def choose(self, selector_window):
        selector_window.withdraw() #.withdraw hides the pet selecting window
        ask_name(selector_window, self.name) #this opens up the name choosing window

class Cat_Option(Pet_Option): #This is the child class that inherits from the parent class which is class Pet_Option
    def __init__(self):
        super().__init__("cat")

class Dog_Option(Pet_Option):
    def __init__(self):
        super().__init__("dog")

class Bunny_Option(Pet_Option):
    def __init__(self):
        super().__init__("bunny")

class Goldfish_Option(Pet_Option):
    def __init__(self):
        super().__init__("goldfish")

class Hamster_Option(Pet_Option):
    def __init__(self):
        super().__init__("hamster")

class TaskCard(ctk.CTkFrame): #This is the class that holds all the attributes and methods for the task
    def __init__(self, parent, task, due, delete_command, change_due_command, button_bg, button_text, box_bg, highlight_bg="#d5e3fa"): #button_bg, button_text, box_bg is the background colour
        super().__init__(parent, fg_color=box_bg, corner_radius=12)
        self.task = task
        self.due = due
        self.selected = False #False is used to keep track whether a task is selected or not. When a task is not selected, it will be false. When a task is selected, it will be True
        self.button_bg = button_bg 
        self.button_text = button_text
        self.normal_bg = box_bg
        self.selected_bg = highlight_bg

        self.label = ctk.CTkLabel(self, text=f"{task}\n(Due: {due})", text_color="black", font=("Arial", 14)) #This is the label for displaying the task that was input
        self.label.pack(padx=10, pady=(8, 4))

        self.button_frame = ctk.CTkFrame(self, fg_color="transparent") #This is a frame to hold all the colour customisation buttons 
        self.button_frame.pack(pady=(0, 8)) #0,8 is the vertical padding with 0px on top and 8px on bottom 

        self.delete_btn = ctk.CTkButton(self.button_frame, text="Delete", width=80, height=25, #This is the button for deleting a task
        corner_radius=8, fg_color=button_bg, text_color=button_text, command=delete_command)
        self.delete_btn.grid(row=0, column=0, padx=4)

        self.change_due_btn = ctk.CTkButton(self.button_frame, text="Deadline", width=80, height=25, #This is the button for changing a deadline for a task
        corner_radius=8, fg_color=button_bg, text_color=button_text,
        command=change_due_command)
        
        self.change_due_btn.grid(row=0, column=1, padx=4)

        self.bind("<Button-1>", self.toggle_select) #This binds the mouse/trackpad control to a function which is selecting the task
        self.label.bind("<Button-1>", self.toggle_select)

    def toggle_select(self, event):
        self.selected = not self.selected #This changes the select from false to true
        self.configure(fg_color=self.selected_bg if self.selected else self.normal_bg) 

    def update_box_colour(self, new_bg):
        self.normal_bg = new_bg  #this changes the background colour to show the user that the task has been selected
        if not self.selected:
            self.configure(fg_color=self.normal_bg) #when a task is not selected, it goes back to original colour

    def update_button_colours(self, button_bg, button_text): 
        self.delete_btn.configure(fg_color=button_bg, text_color=button_text)
        self.change_due_btn.configure(fg_color=button_bg, text_color=button_text)
        try:
            self.label.configure(text_color=button_text)
        except Exception: #Exception is used as a safety measure just in case something goes wrong with the colour customisation, the code will continue running
            pass

class KANBAN: #This is the class that holds all the functions and code for the KANBAN board
    def __init__(self, parent_frame, pet_frame, main_window):
        self.parent_frame = parent_frame
        self.pet_frame = pet_frame
        self.main_window = main_window
        self.window_bg = "#91BEE3" #These are the default colours
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"
        self.taskbox_bg = "#91BEE3"
        self.taskbox_selected_bg = "#d5e3fa"

        self.todo_cards = [] #These are the lists for each KANBAN column to hold all the tasks that are being input by the user
        self.doing_cards = []
        self.completed_cards = []
        
        self.tasks_by_date = {} #This is the dictionary where it stores the duedate, time, and taskname together

        self.parent_frame.configure(fg_color=self.window_bg)
        self.parent_frame.grid_columnconfigure((0, 1, 2), weight=1)
        self.parent_frame.grid_rowconfigure(1, weight=1)

        self.menu_frame = ctk.CTkFrame(self.parent_frame, fg_color=self.column_bg, corner_radius=0)
        self.menu_frame.grid(row=0, column=0, columnspan=3, sticky="ew")

        self.all_buttons = [] #This list is to store all the colour customisation buttons
        self.create_colour_buttons() #This creates the colour customisation buttons

        self.todo_frame = self.create_column("To-do", 0, self.todo_cards) #This creates the 3 KANBAN columns 
        self.doing_frame = self.create_column("Doing", 1, self.doing_cards)
        self.completed_frame = self.create_column("Completed", 2, self.completed_cards)

        self.entry = ctk.CTkEntry(self.parent_frame, width=1010, placeholder_text="Enter task here...") #placeholder_text is the transparent text that shows up when you are not typing in the input box
        self.entry.grid(row=2, column=0, columnspan=3, padx=10, pady=0)

        self.due_entry = ctk.CTkEntry(self.parent_frame, width=480, placeholder_text="Due date (Enter as DD-MM-YYYY)")
        self.due_entry.grid(row=3, column=0, padx=10, pady=10, sticky="w") #sticky=w means that it will stick to the west or the left

        self.time_entry = ctk.CTkEntry(self.parent_frame, width=480, placeholder_text="Time (Enter as HH:MM)")
        self.time_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")

        self.add_button = ctk.CTkButton(self.parent_frame, text="Add Task", command=self.add_task, fg_color=self.button_bg, text_color=self.button_text, width=480) #This is the button to add task
        self.add_button.grid(row=3, column=2, padx=10, pady=5)
        self.all_buttons.append(self.add_button)

    def create_colour_buttons(self):
        btn_params = {"width":120, "height":30, "corner_radius":8} #this is setting the button size for all the buttons

        def make_btn(text, cmd):
            b = ctk.CTkButton(self.menu_frame, text=text, command=cmd, **btn_params) #this creates the buttons
            b.pack(side="left", padx=10, pady=5, expand=True) #expand=true has been used so the buttons fills in any empty space 
            self.all_buttons.append(b) #this adds the buttons to the list so it will be easier to modify the colours later on
            return b

        make_btn("Window Colour", self.pick_window_colour) #this makes a button with the name "Window Colour" and with the function "self.pick_window_colour" 
        make_btn("Column Colour", self.pick_column_colour)
        make_btn("Button Colour", self.pick_button_colour)
        make_btn("Button Text", self.pick_button_text)
        make_btn("Label Text", self.pick_label_text)
        make_btn("Task Box Colour", self.pick_taskbox_colour)
        make_btn("Reset Colours", self.reset_colours)

    def create_column(self, title, col, card_list):
        frame = ctk.CTkFrame(self.parent_frame, fg_color=self.column_bg, corner_radius=20)
        frame.grid(row=1, column=col, padx=10, pady=10, sticky="nsew")

        label = ctk.CTkLabel(frame, text=title, font=("Arial", 16), fg_color="transparent", text_color=self.label_text)
        label.pack(pady=5)

        container = ctk.CTkScrollableFrame(frame, fg_color=self.column_bg) #scrollableframe has been added so if there is a lot of tasks, you can scroll to see them all
        container.pack(expand=True, fill="both", padx=5, pady=5)

        if title == "Completed": #if the button name is "completed", the text on the button will "Clear all" and has the function that clears all the task
            btn_text = "Clear All"
            btn_command = self.clear_completed
        else:
            btn_text = "Move to next column" #otherwise, the button name will be "move to next column" with the function that moves the tasks to the next column
            btn_command = lambda l=card_list: self.move_selected(l)

        move_btn = ctk.CTkButton(frame, text=btn_text, command=btn_command, fg_color=self.button_bg, text_color=self.button_text) #This creates the move to next column button
        move_btn.pack(pady=10, fill="x", padx=10) #fill=x is used so it fills the entire column that it is in horizontally
        self.all_buttons.append(move_btn) #this adds the buttons to the list

        frame.container = container
        frame.card_list = card_list
        frame.move_btn = move_btn
        return frame

    def ask_input(self, title, prompt):
        try:
            dlg = ctk.CTkInputDialog(text=prompt, title=title) #ctk.CTkInputDialog is a dialogue box where you input 
            return dlg.get_input()
        except Exception: #This is to prevent the code from crashing
            return simpledialog.askstring(title, prompt, parent=self.parent_frame)

    def add_task(self):
        task = self.entry.get().strip() #.strip() removes the extra space
        due = self.due_entry.get().strip()
        time = self.time_entry.get().strip()

        if not task or not due: #This will show an error if the entry input is empty
            messagebox.showerror("Error", "Task and due date required!")
            return

        try:
            parsed = datetime.strptime(due, "%d-%m-%Y")
            due_date_str = parsed.strftime("%d-%m-%Y")
            calendar_date_key = parsed.strftime("%Y-%m-%d")  
        except ValueError:  #if the duedate is not typed as DD-MM-YYYY, an error will come up
            messagebox.showerror("Error", "Invalid due date format! Use DD-MM-YYYY.")
            return

        if time:
            try:
                tparsed = datetime.strptime(time, "%H:%M")
                time_str = tparsed.strftime("%H:%M")
            except ValueError:  #if the time is not typed as HH:MM, an error will come up
                messagebox.showerror("Error", "Invalid time format! Use HH:MM (24h).")
                return
            due_display = f"{due_date_str} {time_str}" #This displays it as "duedate" "time"
        else:
            due_display = due_date_str #if nothing is entered for entry input for time, it will just be left as blank

        card = TaskCard(self.todo_frame.container, task, due_display, delete_command=lambda: None, change_due_command=lambda: None, #This creates the taskbox
                        button_bg=self.button_bg, button_text=self.button_text, box_bg=self.taskbox_bg, highlight_bg=self.taskbox_selected_bg) #all the commands have none as it is a placeholder since the functions will be added later
        card.delete_btn.configure(command=lambda c=card: self.delete_task(c, self.todo_cards))
        card.change_due_btn.configure(command=lambda c=card: self.change_due(c))

        try:
            card.label.configure(text_color=self.button_text)
        except Exception:
            pass

        card.pack(fill="x", pady=5, padx=5)
        self.todo_cards.append(card) #This adds the taskbox all into one list for easy configuration later on

        self.add_task_to_calendar(task, due_date_str, time_str if time else None, card) #If no time was inputted, it will be displayed with nothing

        self.entry.delete(0, "end") #This clears whats in the entrybox after a task has been added
        self.due_entry.delete(0, "end") #(0, "end") basically clears from the first index to the end of the sentence
        self.time_entry.delete(0, "end")

        if hasattr(self, 'current_pet') and self.current_pet: #hasattr is used to check if an object has a specific attribute, this prevents the code from crashing
            self.current_pet.show_addtask_animation() #in this case, the object is "self" while the attribute is "current pet", if it does have an attribute, it will return as True 

    def add_task_to_calendar(self, task, due_date, time, card):
        try:
            parsed_date = datetime.strptime(due_date, "%d-%m-%Y") #this converts the date from "DD-MM-YYYY" format into datetime object
            date_key = parsed_date.strftime("%Y-%m-%d") #converting it to datetime object makes it easier to reformat it to "YYYY-MM-DD" which is easier to sort out for dictionary key
            
            task_info = {'task': task, 'due_date': due_date, 'time': time, 'card': card} #This is a dictionary to store all the taskbox information

            if date_key not in self.tasks_by_date: #this checks if the duedate inputted already exists or not, if it doesnt exist, it creates an empty list for that specific date.
                self.tasks_by_date[date_key] = []
            
            self.tasks_by_date[date_key].append(task_info) #this adds the task to the right date
            
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_calendar_display()
                
        except ValueError as e: #this is here to prevent users from entering dates that doesnt exist
            print(f"Error adding task to calendar: {e}")

    def remove_task_from_calendar(self, card): #this removes the task from the calenar
        for date_key, tasks in list(self.tasks_by_date.items()): #ths loops through all the tasks and dates 
            for task_info in tasks[:]: #tasks[:]: has been used to loop throuhg a copy of the tasklist for that date to avoid python from crashing
                if task_info['card'] == card: #this checks if this taskbox mathces the one we are copying
                    tasks.remove(task_info) #this removes the task
                    if not tasks:
                        del self.tasks_by_date[date_key]
                    if hasattr(self, 'calendar_app_ref'):
                        self.calendar_app_ref.update_calendar_display()
                    return

    def move_selected(self, card_list):
        selected = [c for c in card_list if c.selected]
        if not selected: #this warns the user to select a task
            messagebox.showerror("Error", "No task selected!")
            return

        for card in selected:
            if card_list == self.todo_cards: #if the task is in the "to do" column, it will move it to the "doing" column
                new_list = self.doing_cards
                container = self.doing_frame.container
                
            elif card_list == self.doing_cards: : #if the task is in the "doing" column, it will move it to the "completed" column
                new_list = self.completed_cards
                container = self.completed_frame.container
                
            else: #This makes sure the taskbox only moves from those two columns
                continue

            new_card = TaskCard(container, card.task, card.due, delete_command=lambda: None, change_due_command=lambda: None, #this makes a new taskbox with the same info in the next column
                                button_bg=self.button_bg, button_text=self.button_text, box_bg=self.taskbox_bg, highlight_bg=self.taskbox_selected_bg)
            new_card.delete_btn.configure(command=lambda nc=new_card, nl=new_list: self.delete_task(nc, nl)) #nc is new card and nl is new list 
            new_card.change_due_btn.configure(command=lambda nc=new_card: self.change_due(nc))

            try:
                new_card.label.configure(text_color=self.button_text)
                
            except Exception:
                pass
            

            new_card.pack(fill="x", pady=5, padx=5)
            new_list.append(new_card) #this adds the new card to a list for easier configuration

            for tasks in self.tasks_by_date.values():
                for task_info in tasks:
                    if task_info['card'] == card:
                        task_info['card'] = new_card

            card.destroy()
            card_list.remove(card)

        if hasattr(self, 'current_pet') and self.current_pet and selected:
            self.current_pet.show_addtask_animation()

    def clear_completed(self): #This clears all the taskbox in the completed columns
        for card in self.completed_cards[:]:
            self.remove_task_from_calendar(card)
            card.destroy()
            self.completed_cards.remove(card)

    def delete_task(self, card, card_list): 
        self.remove_task_from_calendar(card)
        if card in card_list:
            card_list.remove(card)
        card.destroy() #this destorys the task in any column
        
        if hasattr(self, 'current_pet') and self.current_pet: #after a task is destoryed, one of the _deletetask will be shown
            self.current_pet.show_deletetask_animation()

    def change_due(self, card): 
        new_due = self.ask_input("Change Due Date", "Enter new due date (DD-MM-YYYY):")
        if not new_due: #if the duedate inputted is the same, nothing changes
            return

        try:
            parsed_date = datetime.strptime(new_due, "%d-%m-%Y")
            new_due_str = parsed_date.strftime("%d-%m-%Y")
        except ValueError:
            messagebox.showerror("Error", "Invalid date format! Use DD-MM-YYYY.")
            return

        self.parent_frame.after(100, lambda: self.ask_time_and_update(card, new_due_str)) 

    def ask_time_and_update(self, card, new_due_str):
        new_time = simpledialog.askstring("Change Time", "Enter new time (HH:MM, optional):", parent=self.parent_frame)
        
        self.remove_task_from_calendar(card)
        
        if new_time:
            try:
                parsed_time = datetime.strptime(new_time, "%H:%M")
                new_time_str = parsed_time.strftime("%H:%M")
                card.due = f"{new_due_str} {new_time_str}"
            except ValueError:
                messagebox.showerror("Error", "Invalid time format! Use HH:MM.")
                return
        else:
            card.due = new_due_str
            new_time_str = None

        card.label.configure(text=f"{card.task}\n(Due: {card.due})")
        
        self.add_task_to_calendar(card.task, new_due_str, new_time_str, card)

    #all of these functions are for colour customisation  
    def pick_window_colour(self): #This is the colour customisation for the window background
        colour = colorchooser.askcolor()[1] #[1] is used for hexcode like #ffffff while [0] is for RGB tuple
        
        if colour:
            self.window_bg = colour
            self.parent_frame.configure(fg_color=self.window_bg)
            self.pet_frame.configure(bg=self.window_bg)
            self.main_window.configure(bg=self.window_bg)
            
            if hasattr(self, 'current_pet') and self.current_pet:
                self.current_pet.update_background_color(self.window_bg)
                
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_window_colour(self.window_bg)

    def pick_column_colour(self): #This is the colour customisation for the columns
        colour = colorchooser.askcolor()[1]
        
        if colour:
            self.column_bg = colour
            
            for f in [self.menu_frame, self.todo_frame, self.doing_frame, self.completed_frame]: #this loops through all the frames in the list
                f.configure(fg_color=self.column_bg)
                
                if hasattr(f, "container"): 
                    f.container.configure(fg_color=self.column_bg)
                    
            if hasattr(self, 'calendar_app_ref'): #this changes the colours for the columns in the calendar
                self.calendar_app_ref.update_column_colour(self.column_bg)

    def pick_button_colour(self): #This is the colour customisation for the buttons
        colour = colorchooser.askcolor()[1]
        
        if colour:
            self.button_bg = colour
            self.refresh_buttons()
            
            if hasattr(self, 'calendar_app_ref'): #this changes the colours for the buttons in the calendar
                self.calendar_app_ref.update_button_colour(self.button_bg)
                
            if hasattr(self, 'current_pet') and self.current_pet: #this changes the colours for the buttons on the left side where the pet is
                self.current_pet.update_nav_button_colors(self.button_bg, self.button_text)

    def pick_button_text(self): #This is the colour customisation for button text
        colour = colorchooser.askcolor()[1]
        
        if colour:
            self.button_text = colour
            self.refresh_buttons()
            
            if hasattr(self, 'calendar_app_ref'): #this changes the colours for the button text in the calendar too
                self.calendar_app_ref.update_button_text(self.button_text)
                
            if hasattr(self, 'current_pet') and self.current_pet: #This changes the colours for the button text in the left side where the pet is
                self.current_pet.update_nav_button_colors(self.button_bg, self.button_text)

    def pick_label_text(self): #This is the colour customisation for label text
        colour = colorchooser.askcolor()[1]
        
        if colour:
            self.label_text = colour
            
            for f in [self.todo_frame, self.doing_frame, self.completed_frame]:
                f.children['!ctklabel'].configure(text_color=self.label_text)
                
            if hasattr(self, 'current_pet') and self.current_pet:
                self.current_pet.update_name_color(self.label_text)
                
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_label_text(self.label_text)

    def pick_taskbox_colour(self):#This is the colour customisation for the taskbox
        colour = colorchooser.askcolor()[1]
        
        if colour:
            self.taskbox_bg = colour
            
            for lst in [self.todo_cards, self.doing_cards, self.completed_cards]:
                for c in lst:
                    c.update_box_colour(self.taskbox_bg)

    def refresh_buttons(self): #This is the colour customisation for the buttons
        for btn in self.all_buttons: #this loops through all the buttons in the list
            btn.configure(fg_color=self.button_bg, text_color=self.button_text)
            
        for lst in [self.todo_cards, self.doing_cards, self.completed_cards]:
            for c in lst:
                c.update_button_colours(self.button_bg, self.button_text)

    def reset_colours(self): #this resets all the colours back to normal
        self.window_bg = "#91BEE3" #these are the default colours
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"
        self.taskbox_bg = "#91BEE3"
        self.taskbox_selected_bg = "#d5e3fa"

        self.parent_frame.configure(fg_color=self.window_bg)
        self.pet_frame.configure(bg=self.window_bg)
        self.main_window.configure(bg=self.window_bg)
        
        if hasattr(self, 'current_pet') and self.current_pet:
            self.current_pet.update_background_color(self.window_bg)
            self.current_pet.update_name_color(self.label_text)
            self.current_pet.update_nav_button_colors(self.button_bg, self.button_text)

        for f in [self.menu_frame, self.todo_frame, self.doing_frame, self.completed_frame]:
            f.configure(fg_color=self.column_bg)
            if hasattr(f, "container"):
                f.container.configure(fg_color=self.column_bg)

        for f in [self.todo_frame, self.doing_frame, self.completed_frame]:
            f.children['!ctklabel'].configure(text_color=self.label_text)

        self.refresh_buttons()
        self.update_all_taskbox_colors()
        
        if hasattr(self, 'calendar_app_ref'):
            self.calendar_app_ref.reset_colours()

    def update_all_taskbox_colors(self):
        for card_list in [self.todo_cards, self.doing_cards, self.completed_cards]:
            for card in card_list:
                card.update_box_colour(self.taskbox_bg)

class Calendar: #this is the class that holds all the functions and code for the calendar
    def __init__(self, parent_frame, pet_frame, main_window, kanban_app=None):
        self.parent_frame = parent_frame
        self.pet_frame = pet_frame
        self.main_window = main_window
        self.kanban_app = kanban_app
        
        self.window_bg = "#91BEE3" #these are the default colours
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"

        self.current_year = datetime.now().year #when you open the calendar, it will immediately show the current month and year
        self.current_month = datetime.now().month
        self.selected_day = None #this keeps track if a task is selected or not

        self.parent_frame.configure(fg_color=self.window_bg)
        self.parent_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)
        self.parent_frame.grid_rowconfigure(1, weight=1)

        self.nav_frame = ctk.CTkFrame(self.parent_frame, fg_color=self.column_bg, corner_radius=0)
        self.nav_frame.grid(row=0, column=0, columnspan=7, sticky="ew")

        self.prev_btn = ctk.CTkButton(self.nav_frame, text="<", width=40, command=self.prev_month, fg_color=self.button_bg, text_color=self.button_text) #button to go to the previous month
        self.prev_btn.pack(side="left", padx=10, pady=5)

        self.next_btn = ctk.CTkButton(self.nav_frame, text=">", width=40, command=self.next_month, fg_color=self.button_bg, text_color=self.button_text) #button to go to the nxt month
        self.next_btn.pack(side="right", padx=10, pady=5)
 
        self.month_label = ctk.CTkLabel(self.nav_frame, text="", font=("Arial", 20, "bold"), text_color=self.label_text)
        self.month_label.pack(side="top", pady=5)

        self.cal_frame = ctk.CTkFrame(self.parent_frame, fg_color=self.window_bg)
        self.cal_frame.grid(row=1, column=0, columnspan=7, sticky="nsew", padx=10, pady=10)

        self.day_labels = [] #lsit that holds all the day labels
        self.date_buttons = []  #list that holds all the date buttons
        self.task_labels = {}  #dictionary to hold the task 
        
        self.draw_calendar()

    def draw_calendar(self):
        for widget in self.cal_frame.winfo_children():
            widget.destroy()

        self.day_labels.clear() #this deletes everything/resets everything before remaking the calendar
        self.date_buttons.clear()
        self.task_labels.clear()

        self.month_label.configure(text=f"{calendar.month_name[self.current_month]} {self.current_year}") #this shows the month and year at the top of the calendar

        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] #list that holds all the days in a week
        
        for c, day in enumerate(days): #this loops through every day in the days list and makes a label for it
            lbl = ctk.CTkLabel(self.cal_frame, text=day, font=("Arial", 15, "bold"), fg_color="transparent", text_color=self.label_text)
            lbl.grid(row=0, column=c, padx=2, pady=2, sticky="nsew")
            self.day_labels.append(lbl)

        month_calendar = calendar.Calendar(firstweekday=0).monthdayscalendar(self.current_year, self.current_month) #this calculate how much rows is needed 
        num_rows = len(month_calendar) 

        for r, week in enumerate(month_calendar, start=1): #this creates the box for each day
            for c, day in enumerate(week):
                if day == 0:
                    filler = ctk.CTkLabel(self.cal_frame, text="", fg_color="transparent")
                    filler.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")
                    continue
                
                cell_frame = ctk.CTkFrame(self.cal_frame, fg_color=self.button_bg, corner_radius=8)
                cell_frame.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")
        
                cell_btn = ctk.CTkButton(cell_frame, text=str(day), font=("Arial", 12, "bold"), fg_color="transparent", text_color=self.button_text, hover_color="#3a70c1",
                                        command=lambda d=day: self.select_date(d), width=30, height=30)
                cell_btn.pack(anchor="nw", pady=(5, 0), padx=(5, 0))
                
                task_frame = ctk.CTkScrollableFrame(cell_frame, fg_color=self.column_bg, height=80)
                task_frame.pack(fill="both", expand=True, padx=5, pady=(0, 5))
                
                self.date_buttons.append(cell_btn)
                self.task_labels[(self.current_year, self.current_month, day)] = task_frame

        self.update_calendar_display()

        for i in range(7):
            self.cal_frame.grid_columnconfigure(i, weight=1)
            
        for i in range(1, num_rows + 1):
            self.cal_frame.grid_rowconfigure(i, weight=1)

    def update_calendar_display(self):
        if not self.kanban_app:
            return
            
        for task_frame in self.task_labels.values():
            for widget in task_frame.winfo_children():
                widget.destroy()
        
        for date_key, tasks in self.kanban_app.tasks_by_date.items():
            try:
                task_date = datetime.strptime(date_key, "%Y-%m-%d")
                
                if task_date.year == self.current_year and task_date.month == self.current_month:
                    day = task_date.day
                    task_frame = self.task_labels.get((self.current_year, self.current_month, day))
                    
                    if task_frame:
                        for task_info in tasks:
                            task_text = task_info['task']
                            
                            task_lbl = ctk.CTkLabel(task_frame, text=task_text, font=("Arial", 9), fg_color=self.column_bg,
                                                    text_color=self.label_text, corner_radius=4, wraplength=100) #wrap length is how much a sentence can take before going to the next line
                            task_lbl.pack(fill="x", pady=1, padx=2)
            except ValueError:
                continue

    def select_date(self, day): #this shows any task on a selected date
        self.selected_day = day
        selected_date = f"{self.current_year}-{self.current_month:02d}-{day:02d}"
        print(f"Selected date: {selected_date}")
        
        if self.kanban_app:
            tasks_on_date = self.kanban_app.tasks_by_date.get(selected_date, [])
            
            if tasks_on_date:
                task_list = "\n".join([f"- {task['task']}" for task in tasks_on_date])
                messagebox.showinfo(f"Tasks on {day}/{self.current_month}/{self.current_year}", task_list)
            else:
                messagebox.showinfo(f"Tasks on {day}/{self.current_month}/{self.current_year}", "No tasks due on this date.")

    def prev_month(self): #this does the math for which month and year it is when you press "<" or the previous month
        self.current_month -= 1
        if self.current_month < 1:
            self.current_month = 12
            self.current_year -= 1
        self.draw_calendar()

    def next_month(self):  #this does the math for which month and year it is when you press ">" or the next month
        self.current_month += 1
        if self.current_month > 12:
            self.current_month = 1
            self.current_year += 1
        self.draw_calendar()

    #functions for updating the colours in calendar
    def update_window_colour(self, color):
        self.window_bg = color
        self.parent_frame.configure(fg_color=self.window_bg)
        self.cal_frame.configure(fg_color=self.window_bg)

    def update_column_colour(self, color):
        self.column_bg = color
        self.nav_frame.configure(fg_color=self.column_bg)
        for task_frame in self.task_labels.values():
            task_frame.configure(fg_color=self.column_bg)
        self.update_calendar_display()

    def update_button_colour(self, color):
        self.button_bg = color
        self.prev_btn.configure(fg_color=self.button_bg)
        self.next_btn.configure(fg_color=self.button_bg)
        for btn in self.date_buttons:
            btn.configure(fg_color=self.button_bg)

    def update_button_text(self, color):
        self.button_text = color
        self.prev_btn.configure(text_color=self.button_text)
        self.next_btn.configure(text_color=self.button_text)
        for btn in self.date_buttons:
            btn.configure(text_color=self.button_text)

    def update_label_text(self, color):
        self.label_text = color
        self.month_label.configure(text_color=self.label_text)
        
        for lbl in self.day_labels:
            lbl.configure(text_color=self.label_text)
            
        self.update_calendar_display()

    def reset_colours(self):
        self.window_bg = "#91BEE3"
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"

        self.parent_frame.configure(fg_color=self.window_bg)
        self.cal_frame.configure(fg_color=self.window_bg)
        self.nav_frame.configure(fg_color=self.column_bg)
        
        self.prev_btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        self.next_btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        self.month_label.configure(text_color=self.label_text)
        
        for lbl in self.day_labels:
            lbl.configure(text_color=self.label_text)
        for btn in self.date_buttons:
            btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        
        for task_frame in self.task_labels.values():
            task_frame.configure(fg_color=self.column_bg)
        self.update_calendar_display()

def start_app():  
    selector_window = ctk.CTk() #this is the pet choosing window
    selector_window.title("Choose Your Companion!")
    selector_window.geometry("1440x900+0+0")
    selector_window.configure(fg_color="#91BEE3")

    pets = [Cat_Option(), Dog_Option(), Bunny_Option(), Goldfish_Option(), Hamster_Option()] #list with all the pet options
    labels = []

    text = ctk.CTkLabel(master=selector_window, text="Choose a companion!", text_color="white", fg_color="#91BEE3", font=("Arial", 60))
    text.place(x=430, y=180)

    for i, pet in enumerate(pets):
        normal_img = pet.get_normal_image() #this loads the images in
        hover_img = pet.get_hover_image()

        label = tk.Label(selector_window, image=normal_img, bd=0)
        label.image_normal = normal_img
        label.image_hover = hover_img

        def on_enter(event, lbl=label): #when the cursor hovers over an image, it changes the non_select image to select_image
            lbl.config(image=lbl.image_hover)

        def on_leave(event, lbl=label): #when the cursor leaves the image, it returns back to the non_select image
            lbl.config(image=lbl.image_normal)

        def on_click(event, pet_obj=pet):
            pet_obj.choose(selector_window) #when a pet is clicked on, it sends you to the name choosing windw

        label.bind("<Enter>", on_enter) #this binds the mouse/trackpad control to the function
        label.bind("<Leave>", on_leave)
        label.bind("<Button-1>", on_click)

        label.grid(row=2, column=i, padx=19, pady=(300, 0))
        labels.append(label)

    selector_window.mainloop()

def ask_name(selector_window, selected_pet): #this is the name choosing window
    name_window = tk.Toplevel(selector_window)  
    name_window.title("Name Your Pet")
    name_window.geometry("1440x900+0+0")
    name_window.configure(bg="#91BEE3")

    label = ctk.CTkLabel(master=name_window, text="Choose a name for your companion!", text_color="white", fg_color="#91BEE3", font=("Arial", 60))
    label.grid(row=0, column=0, columnspan=2, pady=230, padx=250)
    
    entry = ctk.CTkEntry(name_window, fg_color="white", font=("Arial", 40), text_color="#163a6e", height=70, width=900, border_width=0, corner_radius=50)
    entry.place(x=280, y=350)

    error_label = tk.Label(name_window, text="", font=("Arial", 20), fg="red", bg="#91BEE3")
    error_label.place(x=610, y=434)

    def submit_name():
        name = entry.get().strip()
        if name: #if a name is enters, it destorys the current window and sends you to the main window
            name_window.destroy()
            open_main_window(selector_window, selected_pet, name)
        else: #a small label below the entrybox will appear to warn the user
            error_label.config(text="Please enter a name!")

    ctk.CTkButton(master=name_window, text="Enter", font=("Arial", 30), command=submit_name, height=30, width=100, corner_radius=1000).place(x=650, y=480)

def open_main_window(selector_window, pet_type, pet_name): #this opens up the main window
    main_window = tk.Toplevel(selector_window) 
    main_window.title(f"Virtual Pet & Productivity App - {pet_name}") #{pet_name} shows the chosen pet name on the title
    main_window.geometry("1440x900+0+0")
    main_window.configure(bg="#91BEE3")
    
    main_window.grid_columnconfigure(0, weight=0)  
    main_window.grid_columnconfigure(1, weight=1) 
    main_window.grid_rowconfigure(0, weight=1)

    left_frame = tk.Frame(main_window, bg="#91BEE3", width=410, height=900)
    left_frame.grid(row=0, column=0, sticky="nsew")
    left_frame.grid_propagate(False)
    
    current_pet = None
    if pet_type == "cat": #whichever pet is chosen will be shown on the left
        current_pet = Cat(left_frame, pet_name)
    elif pet_type == "dog":
        current_pet = Dog(left_frame, pet_name)
    elif pet_type == "bunny":
        current_pet = Bunny(left_frame, pet_name)
    elif pet_type == "goldfish":
        current_pet = Goldfish(left_frame, pet_name)
    elif pet_type == "hamster":
        current_pet = Hamster(left_frame, pet_name)
    
    content_frame = ctk.CTkFrame(main_window, fg_color="#91BEE3", width=1030, height=900) #tis is the right side of the window
    content_frame.grid(row=0, column=1, sticky="nsew")
    content_frame.grid_propagate(False)
    
    kanban_frame = ctk.CTkFrame(content_frame, fg_color="#91BEE3", width=1030, height=900)
    calendar_frame = ctk.CTkFrame(content_frame, fg_color="#91BEE3", width=1030, height=900)
    
    kanban_app = KANBAN(kanban_frame, left_frame, main_window)
    kanban_app.current_pet = current_pet
    
    calendar_app = Calendar(calendar_frame, left_frame, main_window, kanban_app)
    
    kanban_app.calendar_app_ref = calendar_app
    
    def show_kanban(): #this is the function to switch between the KANBAN board and calendar
        calendar_frame.grid_forget()
        kanban_frame.grid(row=0, column=0, sticky="nsew")
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_rowconfigure(0, weight=1)
        
    def show_calendar():
        kanban_frame.grid_forget()
        calendar_frame.grid(row=0, column=0, sticky="nsew")
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_rowconfigure(0, weight=1)
        calendar_app.update_calendar_display()
    
    kanban_btn = ctk.CTkButton(current_pet.nav_buttons_frame, text="KANBAN", font=("Arial", 20, "bold"), fg_color="#2658a3", #the appearnance and location of the KANBAN button
                               text_color="white", height=50, width=180, corner_radius=15, command=show_kanban)
    kanban_btn.pack(side="left", padx=(20, 10), pady=10)
    current_pet.kanban_btn = kanban_btn
    
    calendar_btn = ctk.CTkButton(current_pet.nav_buttons_frame, text="Calendar", font=("Arial", 20, "bold"), fg_color="#2658a3", #the appearnance and location of the calendar button
                                 text_color="white", height=50, width=180, corner_radius=15, command=show_calendar)
    calendar_btn.pack(side="right", padx=(10, 20), pady=10)
    current_pet.calendar_btn = calendar_btn
    
    show_kanban()

if __name__ == "__main__":
    ctk.set_appearance_mode("system")
    start_app()
