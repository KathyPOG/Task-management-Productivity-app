import tkinter as tk
from PIL import Image, ImageTk
import customtkinter as ctk
from tkinter import messagebox, simpledialog, colorchooser
from datetime import datetime
import calendar
import random

class Pet:
    def __init__(self, window, default_img_path, interact_img_path, addtask_img_path, pet_name):
        self.window = window
        self.pet_name = pet_name
        self.default_img_path = default_img_path
        self.interact_img_path = interact_img_path
        self.addtask_img_path = addtask_img_path
        self.load_images(default_img_path, interact_img_path, addtask_img_path)
        
        # Create a frame to position the pet image
        self.container = tk.Frame(window, bg="#91BEE3", width=410, height=900)
        self.container.grid(row=0, column=0, padx=(0, 10))
        self.container.grid_propagate(False)
        
        # Configure grid for proper layout
        self.container.grid_rowconfigure(0, weight=0)  # Navigation buttons
        self.container.grid_rowconfigure(1, weight=1)  # Pet image (centered)
        self.container.grid_rowconfigure(2, weight=0)  # Pet name
        self.container.grid_columnconfigure(0, weight=1)
        
        # Navigation buttons at the top
        self.nav_buttons_frame = tk.Frame(self.container, bg="#91BEE3", width=410, height=80)
        self.nav_buttons_frame.grid(row=0, column=0, sticky="nsew", pady=(10, 10))
        self.nav_buttons_frame.grid_propagate(False)
        
        # Pet image in the middle - use a frame to center it
        self.image_frame = tk.Frame(self.container, bg="#91BEE3", width=410, height=500)
        self.image_frame.grid(row=1, column=0, sticky="nsew", pady=20)
        self.image_frame.grid_propagate(False)
        self.image_frame.grid_rowconfigure(0, weight=1)
        self.image_frame.grid_columnconfigure(0, weight=1)
        
        self.label = tk.Label(self.image_frame, image=self.default_img, bg="#91BEE3")
        self.label.grid(row=0, column=0)
        
        # Pet name at the bottom - make it more prominent
        self.name_label = tk.Label(self.container, text=pet_name, bg="#91BEE3", 
                                  font=("Arial", 28, "bold"), fg="#163a6e",  # Larger font
                                  padx=10, pady=10)
        self.name_label.grid(row=2, column=0, sticky="nsew", pady=(20, 30))
        
        # Store navigation buttons for color updates
        self.kanban_btn = None
        self.calendar_btn = None
        
        self.label.bind("<Button-1>", self.click)
        self.label.bind("<ButtonRelease-1>", self.release)
    
    def load_images(self, default_img_path, interact_img_path, addtask_img_path):
        default_img = Image.open(default_img_path)
        interact_img = Image.open(interact_img_path)
        addtask_img = Image.open(addtask_img_path)
        
        default_img = default_img.resize((410, 500))
        interact_img = interact_img.resize((410, 500))
        addtask_img = addtask_img.resize((410, 500))
        
        self.default_img = ImageTk.PhotoImage(default_img)
        self.interact_img = ImageTk.PhotoImage(interact_img)
        self.addtask_img = ImageTk.PhotoImage(addtask_img)
    
    def click(self, event):
        self.label.config(image=self.interact_img)
    
    def release(self, event):
        self.label.config(image=self.default_img)
    
    def show_addtask_animation(self):
        # Show the add task image
        self.label.config(image=self.addtask_img)
        # Return to default image after 2 seconds (2000 milliseconds)
        self.window.after(2000, lambda: self.label.config(image=self.default_img))
    
    def show_deletetask_animation(self):
        # Randomly choose between deletetask and deletetask2 with equal chance
        if random.choice([True, False]):
            # Use deletetask image
            deletetask_img = Image.open(self.default_img_path.replace("default", "deletetask"))
        else:
            # Use deletetask2 image
            deletetask_img = Image.open(self.default_img_path.replace("default", "deletetask2"))
        
        deletetask_img = deletetask_img.resize((410, 500))
        self.deletetask_img = ImageTk.PhotoImage(deletetask_img)
        
        # Show the delete task image
        self.label.config(image=self.deletetask_img)
        # Return to default image after 2 seconds (2000 milliseconds)
        self.window.after(2000, lambda: self.label.config(image=self.default_img))
    
    def update_background_color(self, color):
        self.label.configure(bg=color)
        self.container.configure(bg=color)
        self.name_label.configure(bg=color)
        self.nav_buttons_frame.configure(bg=color)
        self.image_frame.configure(bg=color)
        self.window.configure(bg=color)
    
    def update_name_color(self, color):
        self.name_label.configure(fg=color)
    
    def update_nav_button_colors(self, button_bg, button_text):
        if self.kanban_btn:
            self.kanban_btn.configure(fg_color=button_bg, text_color=button_text)
        if self.calendar_btn:
            self.calendar_btn.configure(fg_color=button_bg, text_color=button_text)

class Cat(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "cat_default.png", "cat_interact.png", "cat_addtask.png", pet_name)

class Dog(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "dog_default.png", "dog_interact.png", "dog_addtask.png", pet_name)

class Bunny(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "bunny_default.png", "bunny_interact.png", "bunny_addtask.png", pet_name)

class Goldfish(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "goldfish_default.png", "goldfish_interact.png", "goldfish_addtask.png", pet_name)

class Hamster(Pet):
    def __init__(self, window, pet_name):
        super().__init__(window, "hamster_default.png", "hamster_interact.png", "hamster_addtask.png", pet_name)

class Pet_Option:
    def __init__(self, name):
        self.name = name
    
    def get_normal_image(self):
        return ImageTk.PhotoImage(Image.open(f"{self.name}_nonselect.png").resize((250, 250)))
    def get_hover_image(self):
        return ImageTk.PhotoImage(Image.open(f"{self.name}_select.png").resize((250, 250)))

    def choose(self, selector_window):
        selector_window.withdraw()
        ask_name(selector_window, self.name)

class Cat_Option(Pet_Option):
    def __init__(self):
        super().__init__("cat")

class Dog_Option(Pet_Option):
    def __init__(self):
        super().__init__("dog")

class Bunny_Option(Pet_Option):
    def __init__(self):
        super().__init__("bunny")

class Goldfish_Option(Pet_Option):
    def __init__(self):
        super().__init__("goldfish")

class Hamster_Option(Pet_Option):
    def __init__(self):
        super().__init__("hamster")

class TaskCard(ctk.CTkFrame):
    def __init__(self, parent, task, due, delete_command, change_due_command, button_bg, button_text, box_bg, highlight_bg="#d5e3fa"):
        super().__init__(parent, fg_color=box_bg, corner_radius=12)
        self.task = task
        self.due = due
        self.selected = False
        self.button_bg = button_bg
        self.button_text = button_text
        self.normal_bg = box_bg
        self.selected_bg = highlight_bg

        self.label = ctk.CTkLabel(self, text=f"{task}\n(Due: {due})", text_color="black", font=("Arial", 14))
        self.label.pack(padx=10, pady=(8, 4))

        self.button_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.button_frame.pack(pady=(0, 8))

        self.delete_btn = ctk.CTkButton(self.button_frame, text="Delete", width=80, height=25,
        corner_radius=8, fg_color=button_bg, text_color=button_text, command=delete_command)
        self.delete_btn.grid(row=0, column=0, padx=4)

        self.change_due_btn = ctk.CTkButton(self.button_frame, text="Deadline", width=80, height=25,
        corner_radius=8, fg_color=button_bg, text_color=button_text,
        command=change_due_command)
        
        self.change_due_btn.grid(row=0, column=1, padx=4)

        self.bind("<Button-1>", self.toggle_select)
        self.label.bind("<Button-1>", self.toggle_select)

    def toggle_select(self, event):
        self.selected = not self.selected
        self.configure(fg_color=self.selected_bg if self.selected else self.normal_bg)

    def update_box_colour(self, new_bg):
        self.normal_bg = new_bg
        if not self.selected:
            self.configure(fg_color=self.normal_bg)

    def update_button_colours(self, button_bg, button_text):
        self.delete_btn.configure(fg_color=button_bg, text_color=button_text)
        self.change_due_btn.configure(fg_color=button_bg, text_color=button_text)
        try:
            self.label.configure(text_color=button_text)
        except Exception:
            pass

class KANBAN:
    def __init__(self, parent_frame, pet_frame, main_window):
        self.parent_frame = parent_frame
        self.pet_frame = pet_frame
        self.main_window = main_window
        self.window_bg = "#91BEE3"
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"
        self.taskbox_bg = "#91BEE3"
        self.taskbox_selected_bg = "#d5e3fa"

        self.todo_cards = []
        self.doing_cards = []
        self.completed_cards = []
        
        # Store tasks for calendar integration
        self.tasks_by_date = {}

        # Configure parent frame
        self.parent_frame.configure(fg_color=self.window_bg)
        self.parent_frame.grid_columnconfigure((0, 1, 2), weight=1)
        self.parent_frame.grid_rowconfigure(1, weight=1)

        self.menu_frame = ctk.CTkFrame(self.parent_frame, fg_color=self.column_bg, corner_radius=0)
        self.menu_frame.grid(row=0, column=0, columnspan=3, sticky="ew")

        self.all_buttons = []
        self.create_colour_buttons()

        self.todo_frame = self.create_column("To-do", 0, self.todo_cards)
        self.doing_frame = self.create_column("Doing", 1, self.doing_cards)
        self.completed_frame = self.create_column("Completed", 2, self.completed_cards)

        self.entry = ctk.CTkEntry(self.parent_frame, width=1010, placeholder_text="Enter task here...")
        self.entry.grid(row=2, column=0, columnspan=3, padx=10, pady=0)

        self.due_entry = ctk.CTkEntry(self.parent_frame, width=480, placeholder_text="Due date (Enter as DD-MM-YYYY)")
        self.due_entry.grid(row=3, column=0, padx=10, pady=10, sticky="w")

        self.time_entry = ctk.CTkEntry(self.parent_frame, width=480, placeholder_text="Time (Enter as HH:MM)")
        self.time_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")

        self.add_button = ctk.CTkButton(self.parent_frame, text="Add Task", command=self.add_task, fg_color=self.button_bg, text_color=self.button_text, width=480)
        self.add_button.grid(row=3, column=2, padx=10, pady=5)
        self.all_buttons.append(self.add_button)

    def create_colour_buttons(self):
        btn_params = {"width":120, "height":30, "corner_radius":8}

        def make_btn(text, cmd):
            b = ctk.CTkButton(self.menu_frame, text=text, command=cmd, **btn_params)
            b.pack(side="left", padx=10, pady=5, expand=True)
            self.all_buttons.append(b)
            return b

        make_btn("Window Colour", self.pick_window_colour)
        make_btn("Column Colour", self.pick_column_colour)
        make_btn("Button Colour", self.pick_button_colour)
        make_btn("Button Text", self.pick_button_text)
        make_btn("Label Text", self.pick_label_text)
        make_btn("Task Box Colour", self.pick_taskbox_colour)
        make_btn("Reset Colours", self.reset_colours)

    def create_column(self, title, col, card_list):
        frame = ctk.CTkFrame(self.parent_frame, fg_color=self.column_bg, corner_radius=20)
        frame.grid(row=1, column=col, padx=10, pady=10, sticky="nsew")

        label = ctk.CTkLabel(frame, text=title, font=("Arial", 16), fg_color="transparent", text_color=self.label_text)
        label.pack(pady=5)

        container = ctk.CTkScrollableFrame(frame, fg_color=self.column_bg)
        container.pack(expand=True, fill="both", padx=5, pady=5)

        if title == "Completed":
            btn_text = "Clear All"
            btn_command = self.clear_completed
        else:
            btn_text = "Move to next column"
            btn_command = lambda l=card_list: self.move_selected(l)

        move_btn = ctk.CTkButton(frame, text=btn_text, command=btn_command, fg_color=self.button_bg, text_color=self.button_text)
        move_btn.pack(pady=10, fill="x", padx=10)
        self.all_buttons.append(move_btn)

        frame.container = container
        frame.card_list = card_list
        frame.move_btn = move_btn
        return frame

    def ask_input(self, title, prompt):
        try:
            dlg = ctk.CTkInputDialog(text=prompt, title=title)
            return dlg.get_input()
        except Exception:
            return simpledialog.askstring(title, prompt, parent=self.parent_frame)

    def add_task(self):
        task = self.entry.get().strip()
        due = self.due_entry.get().strip()
        time = self.time_entry.get().strip()

        if not task or not due:
            messagebox.showerror("Error", "Task and due date required!")
            return

        try:
            parsed = datetime.strptime(due, "%d-%m-%Y")
            due_date_str = parsed.strftime("%d-%m-%Y")
            calendar_date_key = parsed.strftime("%Y-%m-%d")  # For calendar storage
        except ValueError:
            messagebox.showerror("Error", "Invalid due date format! Use DD-MM-YYYY.")
            return

        if time:
            try:
                tparsed = datetime.strptime(time, "%H:%M")
                time_str = tparsed.strftime("%H:%M")
            except ValueError:
                messagebox.showerror("Error", "Invalid time format! Use HH:MM (24h).")
                return
            due_display = f"{due_date_str} {time_str}"
        else:
            due_display = due_date_str

        card = TaskCard(self.todo_frame.container, task, due_display, delete_command=lambda: None, change_due_command=lambda: None,
                        button_bg=self.button_bg, button_text=self.button_text, box_bg=self.taskbox_bg, highlight_bg=self.taskbox_selected_bg)
        card.delete_btn.configure(command=lambda c=card: self.delete_task(c, self.todo_cards))
        card.change_due_btn.configure(command=lambda c=card: self.change_due(c))

        try:
            card.label.configure(text_color=self.button_text)
        except Exception:
            pass

        card.pack(fill="x", pady=5, padx=5)
        self.todo_cards.append(card)

        # Store task for calendar
        self.add_task_to_calendar(task, due_date_str, time_str if time else None, card)

        self.entry.delete(0, "end")
        self.due_entry.delete(0, "end")
        self.time_entry.delete(0, "end")

        # Show add task animation on the pet
        if hasattr(self, 'current_pet') and self.current_pet:
            self.current_pet.show_addtask_animation()

    def add_task_to_calendar(self, task, due_date, time, card):
        """Add task to calendar data structure"""
        try:
            # Parse the due date
            parsed_date = datetime.strptime(due_date, "%d-%m-%Y")
            date_key = parsed_date.strftime("%Y-%m-%d")
            
            # Create task info
            task_info = {
                'task': task,
                'due_date': due_date,
                'time': time,
                'card': card
            }
            
            # Add to tasks_by_date dictionary
            if date_key not in self.tasks_by_date:
                self.tasks_by_date[date_key] = []
            
            self.tasks_by_date[date_key].append(task_info)
            
            # Update calendar display if it exists
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_calendar_display()
                
        except ValueError as e:
            print(f"Error adding task to calendar: {e}")

    def remove_task_from_calendar(self, card):
        """Remove task from calendar data structure"""
        for date_key, tasks in list(self.tasks_by_date.items()):
            for task_info in tasks[:]:
                if task_info['card'] == card:
                    tasks.remove(task_info)
                    # Remove date key if no tasks left
                    if not tasks:
                        del self.tasks_by_date[date_key]
                    # Update calendar display
                    if hasattr(self, 'calendar_app_ref'):
                        self.calendar_app_ref.update_calendar_display()
                    return

    def move_selected(self, card_list):
        selected = [c for c in card_list if c.selected]
        if not selected:
            messagebox.showerror("Error", "No task selected!")
            return

        for card in selected:
            if card_list == self.todo_cards:
                new_list = self.doing_cards
                container = self.doing_frame.container
                
            elif card_list == self.doing_cards:
                new_list = self.completed_cards
                container = self.completed_frame.container
                
            else:
                continue

            new_card = TaskCard(container, card.task, card.due, delete_command=lambda: None, change_due_command=lambda: None,
                                button_bg=self.button_bg, button_text=self.button_text, box_bg=self.taskbox_bg, highlight_bg=self.taskbox_selected_bg)
            new_card.delete_btn.configure(command=lambda nc=new_card, nl=new_list: self.delete_task(nc, nl))
            new_card.change_due_btn.configure(command=lambda nc=new_card: self.change_due(nc))

            try:
                new_card.label.configure(text_color=self.button_text)
                
            except Exception:
                pass

            new_card.pack(fill="x", pady=5, padx=5)
            new_list.append(new_card)

            # Update the card reference in calendar data
            for tasks in self.tasks_by_date.values():
                for task_info in tasks:
                    if task_info['card'] == card:
                        task_info['card'] = new_card

            card.destroy()
            card_list.remove(card)

        # Show add task animation on the pet when moving tasks
        if hasattr(self, 'current_pet') and self.current_pet and selected:
            self.current_pet.show_addtask_animation()

    def clear_completed(self):
        for card in self.completed_cards[:]:
            # Remove from calendar data
            self.remove_task_from_calendar(card)
            card.destroy()
            self.completed_cards.remove(card)

    def delete_task(self, card, card_list):
        # Remove from calendar data
        self.remove_task_from_calendar(card)
        if card in card_list:
            card_list.remove(card)
        card.destroy()
        
        # Show delete task animation on the pet
        if hasattr(self, 'current_pet') and self.current_pet:
            self.current_pet.show_deletetask_animation()

    def change_due(self, card):
        new_due = self.ask_input("Change Due Date", "Enter new due date (DD-MM-YYYY):")
        if not new_due:
            return

        try:
            parsed_date = datetime.strptime(new_due, "%d-%m-%Y")
            new_due_str = parsed_date.strftime("%d-%m-%Y")
        except ValueError:
            messagebox.showerror("Error", "Invalid date format! Use DD-MM-YYYY.")
            return

        self.parent_frame.after(100, lambda: self.ask_time_and_update(card, new_due_str))

    def ask_time_and_update(self, card, new_due_str):
        new_time = simpledialog.askstring("Change Time", "Enter new time (HH:MM, optional):", parent=self.parent_frame)
        
        # Remove old calendar entry
        self.remove_task_from_calendar(card)
        
        # Update card due date
        if new_time:
            try:
                parsed_time = datetime.strptime(new_time, "%H:%M")
                new_time_str = parsed_time.strftime("%H:%M")
                card.due = f"{new_due_str} {new_time_str}"
            except ValueError:
                messagebox.showerror("Error", "Invalid time format! Use HH:MM.")
                return
        else:
            card.due = new_due_str
            new_time_str = None

        card.label.configure(text=f"{card.task}\n(Due: {card.due})")
        
        # Add updated task to calendar
        self.add_task_to_calendar(card.task, new_due_str, new_time_str, card)

    def pick_window_colour(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.window_bg = colour
            self.parent_frame.configure(fg_color=self.window_bg)
            self.pet_frame.configure(bg=self.window_bg)
            self.main_window.configure(bg=self.window_bg)
            if hasattr(self, 'current_pet') and self.current_pet:
                self.current_pet.update_background_color(self.window_bg)
            # Update calendar window color if it exists
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_window_colour(self.window_bg)

    def pick_column_colour(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.column_bg = colour
            for f in [self.menu_frame, self.todo_frame, self.doing_frame, self.completed_frame]:
                f.configure(fg_color=self.column_bg)
                if hasattr(f, "container"): 
                    f.container.configure(fg_color=self.column_bg)
            # Update calendar navigation color if it exists
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_column_colour(self.column_bg)

    def pick_button_colour(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.button_bg = colour
            self.refresh_buttons()
            # Update calendar button color if it exists
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_button_colour(self.button_bg)
            # Update navigation buttons color
            if hasattr(self, 'current_pet') and self.current_pet:
                self.current_pet.update_nav_button_colors(self.button_bg, self.button_text)

    def pick_button_text(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.button_text = colour
            self.refresh_buttons()
            # Update calendar button text color if it exists
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_button_text(self.button_text)
            # Update navigation buttons text color
            if hasattr(self, 'current_pet') and self.current_pet:
                self.current_pet.update_nav_button_colors(self.button_bg, self.button_text)

    def pick_label_text(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.label_text = colour
            for f in [self.todo_frame, self.doing_frame, self.completed_frame]:
                f.children['!ctklabel'].configure(text_color=self.label_text)
            if hasattr(self, 'current_pet') and self.current_pet:
                self.current_pet.update_name_color(self.label_text)
            # Update calendar label text color if it exists
            if hasattr(self, 'calendar_app_ref'):
                self.calendar_app_ref.update_label_text(self.label_text)

    def pick_taskbox_colour(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.taskbox_bg = colour
            for lst in [self.todo_cards, self.doing_cards, self.completed_cards]:
                for c in lst:
                    c.update_box_colour(self.taskbox_bg)

    def refresh_buttons(self): 
        for btn in self.all_buttons:
            btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        for lst in [self.todo_cards, self.doing_cards, self.completed_cards]:
            for c in lst:
                c.update_button_colours(self.button_bg, self.button_text)

    def reset_colours(self):
        self.window_bg = "#91BEE3"
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"
        self.taskbox_bg = "#91BEE3"
        self.taskbox_selected_bg = "#d5e3fa"

        self.parent_frame.configure(fg_color=self.window_bg)
        self.pet_frame.configure(bg=self.window_bg)
        self.main_window.configure(bg=self.window_bg)
        
        if hasattr(self, 'current_pet') and self.current_pet:
            self.current_pet.update_background_color(self.window_bg)
            self.current_pet.update_name_color(self.label_text)
            self.current_pet.update_nav_button_colors(self.button_bg, self.button_text)

        for f in [self.menu_frame, self.todo_frame, self.doing_frame, self.completed_frame]:
            f.configure(fg_color=self.column_bg)
            if hasattr(f, "container"):
                f.container.configure(fg_color=self.column_bg)

        for f in [self.todo_frame, self.doing_frame, self.completed_frame]:
            f.children['!ctklabel'].configure(text_color=self.label_text)

        self.refresh_buttons()
        
        # Reset calendar colors if it exists
        if hasattr(self, 'calendar_app_ref'):
            self.calendar_app_ref.reset_colours()

class Calendar:
    def __init__(self, parent_frame, pet_frame, main_window, kanban_app=None):
        self.parent_frame = parent_frame
        self.pet_frame = pet_frame
        self.main_window = main_window
        self.kanban_app = kanban_app
        
        self.window_bg = "#91BEE3"
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"

        self.current_year = datetime.now().year
        self.current_month = datetime.now().month
        self.selected_day = None

        # Configure the parent frame
        self.parent_frame.configure(fg_color=self.window_bg)
        self.parent_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)
        self.parent_frame.grid_rowconfigure(1, weight=1)

        # Navigation frame
        self.nav_frame = ctk.CTkFrame(self.parent_frame, fg_color=self.column_bg, corner_radius=0)
        self.nav_frame.grid(row=0, column=0, columnspan=7, sticky="ew")

        self.prev_btn = ctk.CTkButton(self.nav_frame, text="<", width=40, command=self.prev_month, fg_color=self.button_bg, text_color=self.button_text)
        self.prev_btn.pack(side="left", padx=10, pady=5)

        self.next_btn = ctk.CTkButton(self.nav_frame, text=">", width=40, command=self.next_month, fg_color=self.button_bg, text_color=self.button_text)
        self.next_btn.pack(side="right", padx=10, pady=5)

        self.month_label = ctk.CTkLabel(self.nav_frame, text="", font=("Arial", 20, "bold"), text_color=self.label_text)
        self.month_label.pack(side="top", pady=5)

        # Calendar frame
        self.cal_frame = ctk.CTkFrame(self.parent_frame, fg_color=self.window_bg)
        self.cal_frame.grid(row=1, column=0, columnspan=7, sticky="nsew", padx=10, pady=10)

        self.day_labels = []  # Store day labels for color updates
        self.date_buttons = []  # Store date buttons for color updates
        self.task_labels = {}  # Store task labels for each date
        
        self.draw_calendar()

    def draw_calendar(self):
        for widget in self.cal_frame.winfo_children():
            widget.destroy()

        self.day_labels.clear()
        self.date_buttons.clear()
        self.task_labels.clear()

        self.month_label.configure(text=f"{calendar.month_name[self.current_month]} {self.current_year}")

        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        
        for c, day in enumerate(days):
            lbl = ctk.CTkLabel(self.cal_frame, text=day, font=("Arial", 15, "bold"), fg_color="transparent", text_color=self.label_text)
            lbl.grid(row=0, column=c, padx=2, pady=2, sticky="nsew")
            self.day_labels.append(lbl)

        month_calendar = calendar.Calendar(firstweekday=0).monthdayscalendar(self.current_year, self.current_month)
        num_rows = len(month_calendar)

        for r, week in enumerate(month_calendar, start=1):
            for c, day in enumerate(week):
                if day == 0:
                    filler = ctk.CTkLabel(self.cal_frame, text="", fg_color="transparent")
                    filler.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")
                    continue
                
                # Create a frame for each date cell
                cell_frame = ctk.CTkFrame(self.cal_frame, fg_color=self.button_bg, corner_radius=8)
                cell_frame.grid(row=r, column=c, padx=5, pady=5, sticky="nsew")
                
                # Date button
                cell_btn = ctk.CTkButton(cell_frame, text=str(day), font=("Arial", 12, "bold"), 
                                        fg_color="transparent", text_color=self.button_text, hover_color="#3a70c1",
                                        command=lambda d=day: self.select_date(d), width=30, height=30)
                cell_btn.pack(anchor="nw", pady=(5, 0), padx=(5, 0))
                
                # Task display area - make scrollable frame background match column color
                task_frame = ctk.CTkScrollableFrame(cell_frame, fg_color=self.column_bg, height=80)
                task_frame.pack(fill="both", expand=True, padx=5, pady=(0, 5))
                
                self.date_buttons.append(cell_btn)
                self.task_labels[(self.current_year, self.current_month, day)] = task_frame

        # Update calendar display with tasks
        self.update_calendar_display()

        for i in range(7):
            self.cal_frame.grid_columnconfigure(i, weight=1)
        for i in range(1, num_rows + 1):
            self.cal_frame.grid_rowconfigure(i, weight=1)

    def update_calendar_display(self):
        """Update the calendar to show tasks from KANBAN"""
        if not self.kanban_app:
            return
            
        # Clear existing task displays
        for task_frame in self.task_labels.values():
            for widget in task_frame.winfo_children():
                widget.destroy()
        
        # Add tasks to calendar
        for date_key, tasks in self.kanban_app.tasks_by_date.items():
            try:
                # Parse the date key (YYYY-MM-DD)
                task_date = datetime.strptime(date_key, "%Y-%m-%d")
                
                # Only show tasks for current month
                if task_date.year == self.current_year and task_date.month == self.current_month:
                    day = task_date.day
                    task_frame = self.task_labels.get((self.current_year, self.current_month, day))
                    
                    if task_frame:
                        for task_info in tasks:
                            # Create task label with column background color
                            task_text = task_info['task']
                            
                            task_lbl = ctk.CTkLabel(
                                task_frame, 
                                text=task_text,
                                font=("Arial", 9),
                                fg_color=self.column_bg,  # Use column background color
                                text_color=self.label_text,  # Use label text color
                                corner_radius=4,
                                wraplength=100
                            )
                            task_lbl.pack(fill="x", pady=1, padx=2)
            except ValueError:
                continue

    def select_date(self, day):
        self.selected_day = day
        selected_date = f"{self.current_year}-{self.current_month:02d}-{day:02d}"
        print(f"Selected date: {selected_date}")
        
        # Show tasks for selected date
        if self.kanban_app:
            tasks_on_date = self.kanban_app.tasks_by_date.get(selected_date, [])
            if tasks_on_date:
                task_list = "\n".join([f"- {task['task']}" for task in tasks_on_date])
                messagebox.showinfo(f"Tasks on {day}/{self.current_month}/{self.current_year}", task_list)
            else:
                messagebox.showinfo(f"Tasks on {day}/{self.current_month}/{self.current_year}", "No tasks due on this date.")

    def prev_month(self):
        self.current_month -= 1
        if self.current_month < 1:
            self.current_month = 12
            self.current_year -= 1
        self.draw_calendar()

    def next_month(self):
        self.current_month += 1
        if self.current_month > 12:
            self.current_month = 1
            self.current_year += 1
        self.draw_calendar()

    # Color update methods
    def update_window_colour(self, color):
        self.window_bg = color
        self.parent_frame.configure(fg_color=self.window_bg)
        self.cal_frame.configure(fg_color=self.window_bg)

    def update_column_colour(self, color):
        self.column_bg = color
        self.nav_frame.configure(fg_color=self.column_bg)
        # Update all scrollable frames and task labels in the calendar
        for task_frame in self.task_labels.values():
            task_frame.configure(fg_color=self.column_bg)
        self.update_calendar_display()

    def update_button_colour(self, color):
        self.button_bg = color
        self.prev_btn.configure(fg_color=self.button_bg)
        self.next_btn.configure(fg_color=self.button_bg)
        for btn in self.date_buttons:
            btn.configure(fg_color=self.button_bg)

    def update_button_text(self, color):
        self.button_text = color
        self.prev_btn.configure(text_color=self.button_text)
        self.next_btn.configure(text_color=self.button_text)
        for btn in self.date_buttons:
            btn.configure(text_color=self.button_text)

    def update_label_text(self, color):
        self.label_text = color
        self.month_label.configure(text_color=self.label_text)
        for lbl in self.day_labels:
            lbl.configure(text_color=self.label_text)
        # Update task labels when label text color changes
        self.update_calendar_display()

    def reset_colours(self):
        self.window_bg = "#91BEE3"
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"

        self.parent_frame.configure(fg_color=self.window_bg)
        self.cal_frame.configure(fg_color=self.window_bg)
        self.nav_frame.configure(fg_color=self.column_bg)
        
        self.prev_btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        self.next_btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        self.month_label.configure(text_color=self.label_text)
        
        for lbl in self.day_labels:
            lbl.configure(text_color=self.label_text)
        for btn in self.date_buttons:
            btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        
        # Reset calendar task frames
        for task_frame in self.task_labels.values():
            task_frame.configure(fg_color=self.column_bg)
        self.update_calendar_display()

def start_app():
    selector_window = ctk.CTk()
    selector_window.title("Choose Your Companion!")
    selector_window.geometry("1440x900+0+0")
    selector_window.configure(fg_color="#91BEE3")

    pets = [Cat_Option(), Dog_Option(), Bunny_Option(), Goldfish_Option(), Hamster_Option()]
    labels = []

    text = ctk.CTkLabel(master=selector_window, text="Choose a companion!", text_color="white", fg_color="#91BEE3", font=("Arial", 60))
    text.place(x=430, y=180)

    for i, pet in enumerate(pets):
        normal_img = pet.get_normal_image()
        hover_img = pet.get_hover_image()

        label = tk.Label(selector_window, image=normal_img, bd=0)
        label.image_normal = normal_img
        label.image_hover = hover_img

        def on_enter(event, lbl=label):
            lbl.config(image=lbl.image_hover)

        def on_leave(event, lbl=label):
            lbl.config(image=lbl.image_normal)

        def on_click(event, pet_obj=pet):
            pet_obj.choose(selector_window)

        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)
        label.bind("<Button-1>", on_click)

        label.grid(row=2, column=i, padx=19, pady=(300, 0))
        labels.append(label)

    selector_window.mainloop()

def ask_name(selector_window, selected_pet):
    name_window = tk.Toplevel(selector_window)  
    name_window.title("Name Your Pet")
    name_window.geometry("1440x900+0+0")
    name_window.configure(bg="#91BEE3")

    label = ctk.CTkLabel(master=name_window, text="Choose a name for your companion!", text_color="white", fg_color="#91BEE3", font=("Arial", 60))
    label.grid(row=0, column=0, columnspan=2, pady=230, padx=250)
    
    entry = ctk.CTkEntry(name_window, fg_color="white", font=("Arial", 40), text_color="#163a6e", height=70, width=900, border_width=0, corner_radius=50)
    entry.place(x=280, y=350)

    error_label = tk.Label(name_window, text="", font=("Arial", 20), fg="red", bg="#91BEE3")
    error_label.place(x=610, y=434)

    def submit_name():
        name = entry.get().strip()
        if name:
            name_window.destroy()
            open_main_window(selector_window, selected_pet, name)
        else:
            error_label.config(text="Please enter a name!")

    ctk.CTkButton(master=name_window, text="Enter", font=("Arial", 30), command=submit_name, height=30, width=100, corner_radius=1000).place(x=650, y=480)

def open_main_window(selector_window, pet_type, pet_name):
    main_window = tk.Toplevel(selector_window) 
    main_window.title(f"Virtual Pet & Productivity App - {pet_name}")
    main_window.geometry("1440x900+0+0")
    main_window.configure(bg="#91BEE3")
    
    main_window.grid_columnconfigure(0, weight=0)  
    main_window.grid_columnconfigure(1, weight=1) 
    main_window.grid_rowconfigure(0, weight=1)

    # Left side - Pet area (410x900)
    left_frame = tk.Frame(main_window, bg="#91BEE3", width=410, height=900)
    left_frame.grid(row=0, column=0, sticky="nsew")
    left_frame.grid_propagate(False)
    
    # Create pet - this now includes navigation buttons at the top
    current_pet = None
    if pet_type == "cat": 
        current_pet = Cat(left_frame, pet_name)
    elif pet_type == "dog":
        current_pet = Dog(left_frame, pet_name)
    elif pet_type == "bunny":
        current_pet = Bunny(left_frame, pet_name)
    elif pet_type == "goldfish":
        current_pet = Goldfish(left_frame, pet_name)
    elif pet_type == "hamster":
        current_pet = Hamster(left_frame, pet_name)
    
    # Right side - Content area (1030x900)
    content_frame = ctk.CTkFrame(main_window, fg_color="#91BEE3", width=1030, height=900)
    content_frame.grid(row=0, column=1, sticky="nsew")
    content_frame.grid_propagate(False)
    
    # Create separate frames for KANBAN and Calendar
    kanban_frame = ctk.CTkFrame(content_frame, fg_color="#91BEE3", width=1030, height=900)
    calendar_frame = ctk.CTkFrame(content_frame, fg_color="#91BEE3", width=1030, height=900)
    
    # Create KANBAN instance first
    kanban_app = KANBAN(kanban_frame, left_frame, main_window)
    kanban_app.current_pet = current_pet
    
    # Create Calendar instance with reference to KANBAN
    calendar_app = Calendar(calendar_frame, left_frame, main_window, kanban_app)
    
    # Link the calendar app reference to KANBAN for color synchronization
    kanban_app.calendar_app_ref = calendar_app
    
    # Function to switch between views
    def show_kanban():
        calendar_frame.grid_forget()
        kanban_frame.grid(row=0, column=0, sticky="nsew")
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_rowconfigure(0, weight=1)
        
    def show_calendar():
        kanban_frame.grid_forget()
        calendar_frame.grid(row=0, column=0, sticky="nsew")
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_rowconfigure(0, weight=1)
        # Refresh calendar display when switching to calendar view
        calendar_app.update_calendar_display()
    
    # Add navigation buttons to the pet's navigation frame and store references
    kanban_btn = ctk.CTkButton(
        current_pet.nav_buttons_frame, 
        text="KANBAN", 
        font=("Arial", 20, "bold"),
        fg_color="#2658a3",
        text_color="white",
        height=50,
        width=180,
        corner_radius=15,
        command=show_kanban
    )
    kanban_btn.pack(side="left", padx=(20, 10), pady=10)
    current_pet.kanban_btn = kanban_btn
    
    calendar_btn = ctk.CTkButton(
        current_pet.nav_buttons_frame, 
        text="Calendar", 
        font=("Arial", 20, "bold"),
        fg_color="#2658a3", 
        text_color="white",
        height=50,
        width=180,
        corner_radius=15,
        command=show_calendar
    )
    calendar_btn.pack(side="right", padx=(10, 20), pady=10)
    current_pet.calendar_btn = calendar_btn
    
    # Start with KANBAN view
    show_kanban()

if __name__ == "__main__":
    ctk.set_appearance_mode("system")
    start_app()
