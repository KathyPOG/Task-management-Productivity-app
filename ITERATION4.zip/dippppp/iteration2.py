import customtkinter as ctk 
from tkinter import messagebox, simpledialog, colorchooser #this is importing extra modules and libraries
from datetime import datetime

class TaskCard(ctk.CTkFrame): #ctk.CTkframw is like a container/box, it holds all the other items like buttons, labels, etc.
    def __init__(self, parent, task, due, delete_command, change_due_command, button_bg, button_text, box_bg, highlight_bg="#d5e3fa"):
        super().__init__(parent, fg_color=box_bg, corner_radius=12)
        self.task = task
        self.due = due
        self.selected = False #usinf falses keeps tracks whether a task has been selected or not
        self.button_bg = button_bg
        self.button_text = button_text
        self.normal_bg = box_bg
        self.selected_bg = highlight_bg

        self.label = ctk.CTkLabel(self, text=f"{task}\n(Due: {due})", text_color="black", font=("Arial", 14)) #This is establising what the text on the textbox will look like
        self.label.pack(padx=10, pady=(8, 4)) #pack been used instead of place or grid as when you increase the size of the window, all the items will move naturally without distorting it

        self.button_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.button_frame.pack(pady=(0, 8))

        self.delete_btn = ctk.CTkButton(self.button_frame, text="Delete", width=80, height=25, #This is creating the button for deleting a task
        corner_radius=8, fg_color=button_bg, text_color=button_text, command=delete_command)
        self.delete_btn.grid(row=0, column=0, padx=4)

        self.change_due_btn = ctk.CTkButton(self.button_frame, text="Deadline", width=80, height=25, #This is creating the button for changing deadline
        corner_radius=8, fg_color=button_bg, text_color=button_text,
        command=change_due_command)
        
        self.change_due_btn.grid(row=0, column=1, padx=4)

        self.bind("<Button-1>", self.toggle_select) #self.bind is binding the control to the self.toggle_select function so when you click on the taskbox, the function will happen
        self.label.bind("<Button-1>", self.toggle_select)

    def toggle_select(self, event):
        self.selected = not self.selected #When a taskbox is not selected, the taskbox will display either the default colour or the colour the user has chosen
        self.configure(fg_color=self.selected_bg if self.selected else self.normal_bg)

    def update_box_colour(self, new_bg):
        self.normal_bg = new_bg #When a taskbox is selected, the taskbox will a highlighted colour to show the user the taskbox has been selected
        if not self.selected: #When the taskbox is not selected, it will return back to the previous colour
            self.configure(fg_color=self.normal_bg)

    def update_button_colours(self, button_bg, button_text):
        self.delete_btn.configure(fg_color=button_bg, text_color=button_text) #This changes the button colours when the button_bg is altered
        self.change_due_btn.configure(fg_color=button_bg, text_color=button_text)
        try:
            self.label.configure(text_color=button_text)
        except Exception: #except exception has used just in case the colour alteration fails, this prevents the program from crashing
            pass

class KANBAN:
    def __init__(self, window):
        self.window = window #This is creating the main window of the KANBAN board
        self.window.title("KANBAN Board")
        self.window.geometry("1030x900")

        self.window_bg = "#91BEE3" #These are the default colours
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"
        self.taskbox_bg = "#91BEE3"
        self.taskbox_selected_bg = "#d5e3fa"

        self.todo_cards = [] #These are the lists to store the tasks
        self.doing_cards = []
        self.completed_cards = []

        self.menu_frame = ctk.CTkFrame(self.window, fg_color=self.column_bg, corner_radius=0)
        self.menu_frame.grid(row=0, column=0, columnspan=3, sticky="ew")

        self.all_buttons = []  # store all buttons for dynamic colour changes
        self.create_colour_buttons()

        self.todo_frame = self.create_column("To-do", 0, self.todo_cards) #the 0, 1, and 2 representns the column so 0 means column=0
        self.doing_frame = self.create_column("Doing", 1, self.doing_cards)
        self.completed_frame = self.create_column("Completed", 2, self.completed_cards)

        self.entry = ctk.CTkEntry(self.window, width=1010, placeholder_text="Enter task here...") #placeholder_text is the text u seen where you are not typing in the entrybox
        self.entry.grid(row=2, column=0, columnspan=3, padx=10, pady=0)

        self.due_entry = ctk.CTkEntry(self.window, width=480, placeholder_text="Due date (Enter as DD-MM-YYYY)")
        self.due_entry.grid(row=3, column=0, padx=10, pady=10, sticky="w")

        self.time_entry = ctk.CTkEntry(self.window, width=480, placeholder_text="Time (Enter as HH:MM)")
        self.time_entry.grid(row=3, column=1, padx=10, pady=10, sticky="w")

        self.add_button = ctk.CTkButton(self.window, text="Add Task", command=self.add_task, fg_color=self.button_bg, text_color=self.button_text, width=480)
        self.add_button.grid(row=3, column=2, padx=10, pady=5)
        self.all_buttons.append(self.add_button)

        self.window.configure(fg_color=self.window_bg)

    def create_colour_buttons(self): 
        btn_params = {"width":120, "height":30, "corner_radius":8} #This sets the size for all the buttons

        def make_btn(text, cmd): #The function that creates each button with the exact same height and width etc.
            b = ctk.CTkButton(self.menu_frame, text=text, command=cmd, **btn_params)
            b.pack(side="left", padx=10, pady=5, expand=True) #expand True makes the buttons expand horizontally if the frame is stretched, it avoids distorting the buttons
            self.all_buttons.append(b) 
            return b

        make_btn("Window Colour", self.pick_window_colour) #make_btn creates each button
        make_btn("Column Colour", self.pick_column_colour)
        make_btn("Button Colour", self.pick_button_colour)
        make_btn("Button Text", self.pick_button_text)
        make_btn("Label Text", self.pick_label_text)
        make_btn("Task Box Colour", self.pick_taskbox_colour)
        make_btn("Reset Colours", self.reset_colours)

    def create_column(self, title, col, card_list):
        frame = ctk.CTkFrame(self.window, fg_color=self.column_bg, corner_radius=20)
        frame.grid(row=1, column=col, padx=10, pady=10, sticky="nsew")

        label = ctk.CTkLabel(frame, text=title, font=("Arial", 16), fg_color="transparent", text_color=self.label_text)
        label.pack(pady=5)

        container = ctk.CTkScrollableFrame(frame, fg_color=self.column_bg)
        container.pack(expand=True, fill="both", padx=5, pady=5)

        if title == "Completed":
            btn_text = "Clear All"
            btn_command = self.clear_completed
        else:
            btn_text = "Move to next column"
            btn_command = lambda l=card_list: self.move_selected(l)

        move_btn = ctk.CTkButton(frame, text=btn_text, command=btn_command, fg_color=self.button_bg, text_color=self.button_text)
        move_btn.pack(pady=10, fill="x", padx=10)
        self.all_buttons.append(move_btn)

        frame.container = container
        frame.card_list = card_list
        frame.move_btn = move_btn
        return frame

    def ask_input(self, title, prompt):
        try:
            dlg = ctk.CTkInputDialog(text=prompt, title=title)
            return dlg.get_input()
        except Exception:
            return simpledialog.askstring(title, prompt, parent=self.window)

    def add_task(self):
        task = self.entry.get().strip()
        due = self.due_entry.get().strip()
        time = self.time_entry.get().strip()

        if not task or not due: #will show error if the input box is left empty
            messagebox.showerror("Error", "Task and due date required!")
            return

        try:
            parsed = datetime.strptime(due, "%d-%m-%Y") #%d-%m-%Y is the format that it is expecting
            due_str = parsed.strftime("%d-%m-%Y")
        except ValueError:
            messagebox.showerror("Error", "Invalid due date format! Use DD-MM-YYYY.") #will show error if the input box is not input that way
            return

        if time:
            try:
                tparsed = datetime.strptime(time, "%H:%M") #%H:%M is the format that it is expecting
                time_str = tparsed.strftime("%H:%M")
            except ValueError:
                messagebox.showerror("Error", "Invalid time format! Use HH:MM (24h).") #will show error if the input box is not input that way
                return
            due_display = f"{due_str} {time_str}" #This displays the due date and time next to each other in the taskbox
        else:
            due_display = due_str #If the time input is left empty then it wont show anything

        card = TaskCard(self.todo_frame.container, task, due_display, delete_command=lambda: None, change_due_command=lambda: None, #this creates the taskbox with all the buttons in it
                        button_bg=self.button_bg, button_text=self.button_text, box_bg=self.taskbox_bg, highlight_bg=self.taskbox_selected_bg)
        card.delete_btn.configure(command=lambda c=card: self.delete_task(c, self.todo_cards))
        card.change_due_btn.configure(command=lambda c=card: self.change_due(c))

        try:
            card.label.configure(text_color=self.button_text)
        except Exception:
            pass

        card.pack(fill="x", pady=5, padx=5) #This allows the task to fill the entire column
        self.todo_cards.append(card)

        self.entry.delete(0, "end") #This automatically deletes whatever is in the input box after it has been added
        self.due_entry.delete(0, "end")
        self.time_entry.delete(0, "end")

    def move_selected(self, card_list):
        selected = [c for c in card_list if c.selected]
        if not selected: #if a task is not selected, it will show an error
            messagebox.showerror("Error", "No task selected!")
            return

        for card in selected:
            if card_list == self.todo_cards: #this moves the taskbox into the next column 
                new_list = self.doing_cards
                container = self.doing_frame.container
                
            elif card_list == self.doing_cards:
                new_list = self.completed_cards
                container = self.completed_frame.container
                
            else:
                continue

            new_card = TaskCard(container, card.task, card.due, delete_command=lambda: None, change_due_command=lambda: None, #this creates the taskbox with all the buttons in it in the new column
                                button_bg=self.button_bg, button_text=self.button_text, box_bg=self.taskbox_bg, highlight_bg=self.taskbox_selected_bg)
            new_card.delete_btn.configure(command=lambda nc=new_card, nl=new_list: self.delete_task(nc, nl))
            new_card.change_due_btn.configure(command=lambda nc=new_card: self.change_due(nc))

            try:
                new_card.label.configure(text_color=self.button_text)
                
            except Exception:
                pass

            new_card.pack(fill="x", pady=5, padx=5)
            new_list.append(new_card)

            card.destroy() #This destorys the old taskbox in the previos column
            card_list.remove(card)

    def clear_completed(self): #This deletes all the tasks in the completed column
        for card in self.completed_cards[:]:
            card.destroy()
            self.completed_cards.remove(card)

    def delete_task(self, card, card_list): #This deletes the selected task
        if card in card_list:
            card_list.remove(card)
        card.destroy()

    def change_due(self, card):
        new_due = self.ask_input("Change Due Date", "Enter new due date (DD-MM-YYYY):")
        if not new_due:
            return

        try:
            parsed_date = datetime.strptime(new_due, "%d-%m-%Y")
            new_due_str = parsed_date.strftime("%d-%m-%Y")
        except ValueError:
            messagebox.showerror("Error", "Invalid date format! Use DD-MM-YYYY.")
            return

        self.window.after(100, lambda: self.ask_time_and_update(card, new_due_str))

    def ask_time_and_update(self, card, new_due_str):
        new_time = simpledialog.askstring("Change Time", "Enter new time (HH:MM, optional):", parent=self.window)
        if new_time:
            try:
                parsed_time = datetime.strptime(new_time, "%H:%M")
                new_time_str = parsed_time.strftime("%H:%M")
                card.due = f"{new_due_str} {new_time_str}"
            except ValueError:
                messagebox.showerror("Error", "Invalid time format! Use HH:MM.")
                return
        else:
            card.due = new_due_str

        card.label.configure(text=f"{card.task}\n(Due: {card.due})")

    def pick_window_colour(self): #the following functions are all functions to customise the colour of all the components in the app like buttons and texts
        colour = colorchooser.askcolor()[1]
        if colour:
            self.window_bg = colour
            self.window.configure(fg_color=self.window_bg)

    def pick_column_colour(self):
        colour = colorchooser.askcolor()[1] #[1] is used for hexcode like #ffffff while [0] is for RGB tuple
        if colour:
            self.column_bg = colour
            for f in [self.menu_frame, self.todo_frame, self.doing_frame, self.completed_frame]:
                f.configure(fg_color=self.column_bg)
                if hasattr(f, "container"): 
                    f.container.configure(fg_color=self.column_bg)

    def pick_button_colour(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.button_bg = colour
            self.refresh_buttons()

    def pick_button_text(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.button_text = colour
            self.refresh_buttons()

    def pick_label_text(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.label_text = colour
            for f in [self.todo_frame, self.doing_frame, self.completed_frame]:
                f.children['!ctklabel'].configure(text_color=self.label_text)

    def pick_taskbox_colour(self):
        colour = colorchooser.askcolor()[1]
        if colour:
            self.taskbox_bg = colour
            for lst in [self.todo_cards, self.doing_cards, self.completed_cards]:
                for c in lst:
                    c.update_box_colour(self.taskbox_bg)

    def refresh_buttons(self): 
        for btn in self.all_buttons:
            btn.configure(fg_color=self.button_bg, text_color=self.button_text)
        for lst in [self.todo_cards, self.doing_cards, self.completed_cards]:
            for c in lst:
                c.update_button_colours(self.button_bg, self.button_text)

    def reset_colours(self): #This resets all the colours back to the default colours
        self.window_bg = "#91BEE3"
        self.column_bg = "#13366b"
        self.button_bg = "#2658a3"
        self.button_text = "white"
        self.label_text = "white"
        self.taskbox_bg = "#91BEE3"
        self.taskbox_selected_bg = "#d5e3fa"

        self.window.configure(fg_color=self.window_bg)

        for f in [self.menu_frame, self.todo_frame, self.doing_frame, self.completed_frame]:
            f.configure(fg_color=self.column_bg)
            if hasattr(f, "container"):  #hasattr is used to prevent errors by checking if the container actually exists before alternating it
                f.container.configure(fg_color=self.column_bg)

        for f in [self.todo_frame, self.doing_frame, self.completed_frame]:
            f.children['!ctklabel'].configure(text_color=self.label_text)

        self.refresh_buttons()

if __name__ == "__main__":
    ctk.set_appearance_mode("system")
    window = ctk.CTk()
    window.grid_columnconfigure((0,1,2), weight=1)
    window.grid_rowconfigure(1, weight=1)

    app = KANBAN(window)
    window.mainloop()
