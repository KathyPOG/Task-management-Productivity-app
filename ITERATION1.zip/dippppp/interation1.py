import tkinter as tk  # This imports tkinter
from PIL import Image, ImageTk  # This imports PIL so I am able to use images

class Pet: #Parent class of interacting with pet
    def __init__(self, window, default_img_path, interact_img_path):
        self.window = window
        self.load_images(default_img_path, interact_img_path) #This finds the picture from the folder and loads it into the code
        
        self.label = tk.Label(window, image=self.default_img) #This displays the cat1.jpg as default 
        self.label.grid()
        
        self.label.bind("<Button-1>", self.click) #This binds the mouse control to the image which is binded to a function
        self.label.bind("<ButtonRelease-1>", self.release)
    
    def load_images(self, default_img_path, interact_img_path):
        default_img = Image.open(default_img_path) #opens the image
        interact_img = Image.open(interact_img_path)
        default_img = default_img.resize((410, 900))  # reiszing the image
        interact_img = interact_img.resize((410, 900))
        
        self.default_img = ImageTk.PhotoImage(default_img) #This converts the jpg into a format that is compatible with tkinter
        self.interact_img = ImageTk.PhotoImage(interact_img)
    
    def click(self, event):  #Function when image is clicked
        self.label.config(image=self.interact_img)  # Changes to interaction image
    
    def release(self, event):  # Function when mouse is released
        self.label.config(image=self.default_img) #event has to be used here to avoid the code from crashing

class Cat(Pet): #Polymorphism is used here to aboid copying and pasting code
    def __init__(self, window):
        super().__init__(window, "cat_default.png", "cat_interact.png") 

class Dog(Pet):
    def __init__(self, window):
        super().__init__(window, "dog_default.png", "dog_interact.png")

class Bunny(Pet):
    def __init__(self, window):
        super().__init__(window, "bunny_default.png", "bunny_interact.png")

class Goldfish(Pet):
    def __init__(self, window):
        super().__init__(window, "goldfish_default.png", "goldfish_interact.png")

class Hamster(Pet):
    def __init__(self, window):
        super().__init__(window, "hamster_default.png", "hamster_interact.png")

class Pet_Option: #Parent class of choosing the pet
    def __init__(self, name):
        self.name = name
    
    def get_normal_image(self):
        return ImageTk.PhotoImage(Image.open(f"{self.name}_nonselect.png").resize((250, 250))) #This opens and loads the image
    def get_hover_image(self):
        return ImageTk.PhotoImage(Image.open(f"{self.name}_select.png").resize((250, 250)))

    def choose(self, selector_window):
        selector_window.withdraw()  #Hide instead of destroy, so we can come back if needed
        ask_name(selector_window, self.name) #This is to run the pet naming window

class Cat_Option(Pet_Option):
    def __init__(self):
        super().__init__("cat")

class Dog_Option(Pet_Option):
    def __init__(self):
        super().__init__("dog")

class Bunny_Option(Pet_Option):
    def __init__(self):
        super().__init__("bunny")

class Goldfish_Option(Pet_Option):
    def __init__(self):
        super().__init__("goldfish")

class Hamster_Option(Pet_Option):
    def __init__(self):
        super().__init__("hamster")

def start_app():
    selector_window = tk.Tk()
    selector_window.title("Choose Your Companion!")
    selector_window.geometry("1440x900")
    selector_window.configure(bg="#91BEE3")

    pets = [Cat_Option(), Dog_Option(), Bunny_Option(), Goldfish_Option(), Hamster_Option()]
    labels = []

    for i, pet in enumerate(pets): #enumerate... write later bro
        normal_img = pet.get_normal_image()
        hover_img = pet.get_hover_image()

        label = tk.Label(selector_window, image=normal_img, bd=0) #bd=0 to remove boarder of the image 
        label.image_normal = normal_img
        label.image_hover = hover_img

        def on_enter(event, lbl=label):
            lbl.config(image=lbl.image_hover) #This configures the default img to the interact img when the mouse is hovered on

        def on_leave(event, lbl=label):
            lbl.config(image=lbl.image_normal)

        def on_click(event, pet_obj=pet):
            pet_obj.choose(selector_window)

        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)
        label.bind("<Button-1>", on_click)

        label.grid(row=0, column=i, padx=10, pady=10)
        labels.append(label)

    selector_window.mainloop()

def ask_name(selector_window, selected_pet):
    name_window = tk.Toplevel(selector_window)  
    name_window.title("Name Your Pet")
    name_window.geometry("1440x900")
    name_window.configure(bg="#91BEE3")

    label = tk.Label(name_window, text="Choose a name for you companion!", font=("Arial", 60)).grid(row=0, column=0, columnspan=2, pady=250, padx=250) #ur working here
    
    entry = tk.Entry(name_window, font=("Arial", 35))
    entry.grid(row=1, column=0, columnspan=2, pady=5, padx=10, sticky="ew")

    error_label = tk.Label(name_window, text="", fg="red")
    error_label.grid(row=2, column=0, columnspan=2)

    def submit_name(): #Functions to remind user to not keep the entry box blank
        name = entry.get().strip()
        if name:
            name_window.destroy()
            open_main_window(selector_window, selected_pet, name)
        else:
            error_label.config(text="Please enter a name!")

    tk.Button(name_window, text="Submit", command=submit_name).grid(row=3, column=0, columnspan=2, pady=10) 

def open_main_window(selector_window, pet_type, pet_name):
    window = tk.Toplevel(selector_window) 
    window.title("Pet window")

    if pet_type == "cat": 
        Cat(window)
    elif pet_type == "dog":
        Dog(window)
    elif pet_type == "bunny":
        Bunny(window)
    elif pet_type == "goldfish":
        Goldfish(window)
    elif pet_type == "hamster":
        Hamster(window)

start_app()
